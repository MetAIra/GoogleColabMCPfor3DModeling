# 高ポリを指定面数に減面（X-Part 入力用）
# 使い方: /content/hp/bin/python decimate.py <in.glb> <out.obj> [faces=400000]
import sys, pymeshlab as ml
ms = ml.MeshSet(); ms.load_new_mesh(sys.argv[1])
ms.meshing_decimation_quadric_edge_collapse(targetfacenum=int(sys.argv[3]) if len(sys.argv) > 3 else 400000, preservenormal=True)
ms.save_current_mesh(sys.argv[2]); print('faces', ms.current_mesh().face_number())
