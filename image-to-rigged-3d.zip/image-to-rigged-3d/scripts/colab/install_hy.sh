#!/bin/bash
# Hunyuan3D-2.1（形状＋PBRテクスチャ）環境を /content/hy に構築する。
# Colab 既定の Python 3.13 / CUDA 13 では requirements が通らないため、Python 3.10 の venv を別に作る。
# 使い方: bash install_hy.sh > /content/install_hy.log 2>&1   （完了で "INSTALL_HY_DONE"）
# 前提: nvcc 13.x（Colab 2026 時点）。nvcc が 12.x の環境なら TORCH_INDEX を cu12x 系に変える。
set -x
cd /content
TORCH_INDEX=${TORCH_INDEX:-https://download.pytorch.org/whl/cu130}
TORCH_VER=${TORCH_VER:-2.9.1}
TV_VER=${TV_VER:-0.24.1}
[ -d Hunyuan3D-2.1 ] || git clone --depth 1 https://github.com/Tencent-Hunyuan/Hunyuan3D-2.1.git
uv venv --python 3.10 /content/hy
PY=/content/hy/bin/python
uv pip install --python $PY torch==$TORCH_VER torchvision==$TV_VER --index-url $TORCH_INDEX
# requirements の修正: bpy(wheel無し)/deepspeed(不要) を除外、cupy は CUDA13 版、setuptools<80（pkg_resources 必須）
grep -v -E "extra-index-url|cupy-cuda12x|deepspeed|^bpy|^#|^$" Hunyuan3D-2.1/requirements.txt > /content/req_hy.txt
echo "cupy-cuda13x" >> /content/req_hy.txt
uv pip install --python $PY -r /content/req_hy.txt
uv pip install --python $PY "setuptools<80" wheel hf_xet
# bpy の import を任意化（OBJ→GLB 変換はローカル Blender で行う）
sed -i 's/^import bpy$/try:\n    import bpy\nexcept ImportError:\n    bpy = None/' Hunyuan3D-2.1/hy3dpaint/DifferentiableRenderer/mesh_utils.py
# custom_rasterizer（CUDA 拡張）
export PATH=/content/hy/bin:$PATH CUDA_HOME=/usr/local/cuda TORCH_CUDA_ARCH_LIST="${TORCH_CUDA_ARCH_LIST:-8.0}"
cd /content/Hunyuan3D-2.1/hy3dpaint/custom_rasterizer && uv pip install --python $PY --no-build-isolation -e .
# mesh_inpaint_processor（compile_mesh_painter.sh は python3-config が無く失敗するので直接ビルド）
cd /content/Hunyuan3D-2.1/hy3dpaint/DifferentiableRenderer
c++ -O3 -shared -std=c++11 -fPIC $($PY -m pybind11 --includes) mesh_inpaint_processor.cpp \
  -o mesh_inpaint_processor$($PY -c "import sysconfig;print(sysconfig.get_config_var('EXT_SUFFIX'))")
ls -la *.so
cd /content/Hunyuan3D-2.1 && mkdir -p hy3dpaint/ckpt
[ -f hy3dpaint/ckpt/RealESRGAN_x4plus.pth ] || wget -q https://github.com/xinntao/Real-ESRGAN/releases/download/v0.1.0/RealESRGAN_x4plus.pth -P hy3dpaint/ckpt
$PY -c "import torch, custom_rasterizer, pkg_resources; print('HY_ENV_OK', torch.__version__, torch.cuda.is_available())"
# 重みを先に取得
$PY -c "
import huggingface_hub as h
h.snapshot_download('tencent/Hunyuan3D-2.1', allow_patterns=['hunyuan3d-paintpbr-v2-1/*'])  # 形状モデルは初回実行時に自動取得
h.snapshot_download('facebook/dinov2-giant')
print('HY_WEIGHTS_OK')"
echo INSTALL_HY_DONE
