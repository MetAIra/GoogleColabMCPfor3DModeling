# Hunyuan3D-2.1 PBR テクスチャ生成（4K、減面ターゲット指定、参照画像の複数指定に対応）
# 使い方: /content/hy/bin/python gen_tex.py <shape.glb> <img1.png[,img2.png,...]> <out_dir/textured_mesh.obj> [faces=100000]
#   参照画像をカンマ区切りで複数渡すと、全てを参照アテンションに入れる（先頭が DINO 条件 = 主画像。正面を先頭に）。
#   例: front_clean.png,back.png,left.png,right.png  ※背面・側面の色の再現が上がる想定。単一画像版と必ず見比べること
# 出力: textured_mesh.obj/.mtl, textured_mesh.jpg(albedo 4K), _metallic.jpg, _roughness.jpg。約3分(A100)
import sys, os, time, shutil
sys.path.insert(0, '/content/Hunyuan3D-2.1/hy3dpaint')
sys.path.insert(0, '/content/Hunyuan3D-2.1')
os.chdir('/content/Hunyuan3D-2.1')
# textureGenPipeline は image_path にリストを渡すと未定義変数で落ちるため、リスト対応のパッチを当てる（冪等）
_tp = 'hy3dpaint/textureGenPipeline.py'
_src = open(_tp, encoding='utf-8').read()
_old = ("        if not isinstance(image_prompt, List):\n"
        "            image_prompt = [image_prompt]\n"
        "        else:\n"
        "            image_prompt = image_path\n")
_new = ("        if isinstance(image_path, list):\n"
        "            image_prompt = [Image.open(p) if isinstance(p, str) else p for p in image_path]\n"
        "        if not isinstance(image_prompt, List):\n"
        "            image_prompt = [image_prompt]\n")
if _old in _src:
    open(_tp, 'w', encoding='utf-8').write(_src.replace(_old, _new)); print('patched textureGenPipeline for list input')
try:
    from torchvision_fix import apply_fix; apply_fix()
except Exception as e:
    print('torchvision_fix skipped:', e)
import utils.simplify_mesh_utils as smu
import textureGenPipeline as tgp
from textureGenPipeline import Hunyuan3DPaintPipeline, Hunyuan3DPaintConfig

mesh_path, img_arg, out_obj = sys.argv[1], sys.argv[2], sys.argv[3]
faces = int(sys.argv[4]) if len(sys.argv) > 4 else 100000
imgs = [p for p in img_arg.split(',') if p]
img_path = imgs[0] if len(imgs) == 1 else imgs
_orig = smu.mesh_simplify_trimesh
smu.remesh_mesh = lambda i, o: _orig(i, o, target_count=faces)
tgp.remesh_mesh = smu.remesh_mesh

conf = Hunyuan3DPaintConfig(max_num_view=9, resolution=768)
conf.realesrgan_ckpt_path = 'hy3dpaint/ckpt/RealESRGAN_x4plus.pth'
conf.multiview_cfg_path = 'hy3dpaint/cfgs/hunyuan-paint-pbr.yaml'
conf.custom_pipeline = 'hy3dpaint/hunyuanpaintpbr'
pipe = Hunyuan3DPaintPipeline(conf)
_sm = pipe.render.save_mesh          # 4K のまま保存（既定は半分に縮小）
pipe.render.save_mesh = lambda p, downsample=True: _sm(p, downsample=False)
t = time.time()
os.makedirs(os.path.dirname(out_obj), exist_ok=True)
work = os.path.join(os.path.dirname(out_obj), 'tmp'); os.makedirs(work, exist_ok=True)
src = os.path.join(work, 'white_mesh.glb'); shutil.copy(mesh_path, src)
print('reference images:', imgs)
out = pipe(mesh_path=src, image_path=img_path, output_mesh_path=out_obj, save_glb=False)
print('TEX_DONE', out, f'{time.time()-t:.1f}s')
