#!/bin/bash
# Hunyuan3D-Part（P3-SAM + X-Part）環境を /content/hp に構築する（CUDA12.4 系 wheel を使う別 venv）
# 使い方: bash install_part.sh > /content/install_part.log 2>&1   （完了で "INSTALL_PART_DONE"）
set -x
cd /content
[ -d Hunyuan3D-Part ] || git clone --depth 1 https://github.com/Tencent-Hunyuan/Hunyuan3D-Part.git
uv venv --python 3.10 /content/hp
P=/content/hp/bin/python
uv pip install --python $P torch==2.5.1 torchvision==0.20.1 --index-url https://download.pytorch.org/whl/cu124
uv pip install --python $P torch_scatter torch_cluster -f https://data.pyg.org/whl/torch-2.5.0+cu124.html
uv pip install --python $P spconv-cu124 "numpy<2.2" addict scikit-learn fpsample "pymeshlab==2023.12.post3" easydict \
  trimesh numba diffusers einops omegaconf "pytorch_lightning<2.5" timm torchdiffeq scikit-image huggingface_hub hf_xet \
  safetensors scipy tqdm pyyaml "setuptools<80" transformers accelerate viser
# Sonata は flash_attn 必須
uv pip install --python $P "https://github.com/Dao-AILab/flash-attention/releases/download/v2.7.4.post1/flash_attn-2.7.4.post1+cu12torch2.5cxx11abiFALSE-cp310-cp310-linux_x86_64.whl"
# P3-SAM のプロンプトバッチ 64 は 80GB 前提 → 40GB(A100) 向けに 16 へ
sed -i 's/^        bs = 64$/        bs = 16/' /content/Hunyuan3D-Part/XPart/partgen/bbox_estimator/auto_mask_api.py
$P -c "import torch, spconv.pytorch, torch_scatter, torch_cluster, flash_attn; print('PART_ENV_OK', torch.__version__, torch.cuda.is_available())"
$P -c "from huggingface_hub import snapshot_download; snapshot_download('tencent/Hunyuan3D-Part'); print('PART_DL_DONE')"
echo INSTALL_PART_DONE
