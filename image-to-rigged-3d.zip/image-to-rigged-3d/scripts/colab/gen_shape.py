# Hunyuan3D-2.1 形状生成（複数シードで候補を作る）
# 使い方: /content/hy/bin/python gen_shape.py <input_rgba.png> <out_dir> [seeds=42,1234,2025] [octree=512]
# 出力: <out_dir>/shape_s<seed>.glb（約150万面、Y-up）。1シード約1分(A100)
import sys, os, time, torch
sys.path.insert(0, '/content/Hunyuan3D-2.1/hy3dshape')
os.chdir('/content/Hunyuan3D-2.1')
from PIL import Image
from hy3dshape.pipelines import Hunyuan3DDiTFlowMatchingPipeline
from hy3dshape import FloaterRemover, DegenerateFaceRemover

img_path, out_dir = sys.argv[1], sys.argv[2]
seeds = [int(s) for s in sys.argv[3].split(',')] if len(sys.argv) > 3 else [42, 1234, 2025]
octree = int(sys.argv[4]) if len(sys.argv) > 4 else 512
os.makedirs(out_dir, exist_ok=True)
pipe = Hunyuan3DDiTFlowMatchingPipeline.from_pretrained('tencent/Hunyuan3D-2.1')
image = Image.open(img_path).convert('RGBA')
for seed in seeds:
    t = time.time()
    mesh = pipe(image=image, num_inference_steps=50, guidance_scale=5.0,
                octree_resolution=octree, num_chunks=200000,
                generator=torch.manual_seed(seed))[0]
    mesh = FloaterRemover()(mesh)
    mesh = DegenerateFaceRemover()(mesh)
    p = f'{out_dir}/shape_s{seed}.glb'
    mesh.export(p)
    print(f'seed {seed}: faces={len(mesh.faces)} {time.time()-t:.1f}s -> {p}', flush=True)
print('SHAPE_DONE')
