# X-Part パーツ分解（隠れた部分も補完して生成）
# 使い方: PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True /content/hp/bin/python run_xpart.py <mesh> <out_dir> [aabb.json] [seed]
#   mesh: 40万面程度に減面した高ポリ（obj/glb）。2段目以降は前回の part_XX.glb を入力にする
#   aabb.json: 任意。[[min_xyz],[max_xyz]] のリスト（入力メッシュ座標）。省略時は P3-SAM の自動検出
# 出力: part_XX.glb（入力と同じ座標系に戻される）, parts.json（面数と bounds）, explode.glb ほか。1回 1〜2 分
import os, sys, json, time, torch, trimesh
from pathlib import Path
ROOT = '/content/Hunyuan3D-Part/XPart'
sys.path.insert(0, ROOT); sys.path.insert(0, '/content/Hunyuan3D-Part/P3-SAM')
os.chdir(ROOT)
import pytorch_lightning as pl
from partgen.partformer_pipeline import PartFormerPipeline

mesh_path, out_dir = sys.argv[1], Path(sys.argv[2])
aabb_json = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3] not in ('', '-') else None
seed = int(sys.argv[4]) if len(sys.argv) > 4 else 2026
out_dir.mkdir(parents=True, exist_ok=True)
pl.seed_everything(seed, workers=True)
pipe = PartFormerPipeline.from_pretrained(model_path='tencent/Hunyuan3D-Part', verbose=True)
pipe.to(device='cuda', dtype=torch.float32)
kw = dict(mesh_path=mesh_path, octree_resolution=512, output_type='trimesh')
if aabb_json:
    kw['aabb'] = torch.tensor(json.load(open(aabb_json)), dtype=torch.float32)
t = time.time()
obj_mesh, (out_bbox, mesh_gt_bbox, explode_object) = pipe(**kw)
print('time', time.time() - t)
obj_mesh.export(out_dir / 'parts.glb')
explode_object.export(out_dir / 'explode.glb')
info = []
if isinstance(obj_mesh, trimesh.Scene):
    for i, (name, g) in enumerate(obj_mesh.geometry.items()):
        g.export(out_dir / f'part_{i:02d}.glb')
        info.append(dict(i=i, faces=int(len(g.faces)), bounds=[[round(x, 4) for x in b] for b in g.bounds.tolist()]))
json.dump(info, open(out_dir / 'parts.json', 'w'), indent=1)
print('parts', len(info))
print('XPART_DONE')
