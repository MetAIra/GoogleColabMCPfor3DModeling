# 入力画像の前処理: 背景除去(isnet-anime) → 除外矩形をマスク → 最大連結成分のみ残す → 正方形パディング 1024px
# 使い方: python preprocess.py <src.png> <dst.png> [exclude_rects_json]
#   exclude_rects_json: 元画像座標の [[y0,y1,x0,x1], ...]（ペット・小物など、キャラ本体以外を消す）
# 出力: dst.png（RGBA）と dst_preview.jpg（白背景、目視確認用）
import sys, json, numpy as np
from PIL import Image
from rembg import remove, new_session
from scipy import ndimage

src, dst = sys.argv[1], sys.argv[2]
rects = json.loads(sys.argv[3]) if len(sys.argv) > 3 else []
img = Image.open(src).convert('RGB')
model = 'isnet-anime'   # 実写なら 'birefnet-general' や 'isnet-general-use'
rgba = remove(img, session=new_session(model), alpha_matting=False)
a = np.array(rgba)
for y0, y1, x0, x1 in rects:
    a[y0:y1, x0:x1, 3] = 0
alpha = a[..., 3]
lab, n = ndimage.label(alpha > 32)
sizes = ndimage.sum(np.ones_like(lab), lab, range(1, n + 1))
keep = int(np.argmax(sizes)) + 1
mask = ndimage.binary_dilation(lab == keep, iterations=3)
a[..., 3] = np.where(mask, alpha, 0)
print('components:', n, 'largest:', int(sizes.max()) if n else 0)
ys, xs = np.where(a[..., 3] > 0)
a = a[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
h, w = a.shape[:2]
s = int(max(h, w) * 1.1)
canvas = np.zeros((s, s, 4), np.uint8)
oy, ox = (s - h) // 2, (s - w) // 2
canvas[oy:oy + h, ox:ox + w] = a
Image.fromarray(canvas).resize((1024, 1024), Image.LANCZOS).save(dst)
im = Image.fromarray(canvas).resize((512, 512))
bg = Image.new('RGBA', im.size, (255, 255, 255, 255)); bg.alpha_composite(im)
bg.convert('RGB').save(dst.rsplit('.', 1)[0] + '_preview.jpg')
print('saved', dst)
