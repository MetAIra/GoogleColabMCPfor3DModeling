# 90: テストポーズ（腕/脚/首/揺れもの）と指テスト（左グー・右ピース）を付けて確認レンダーし、元に戻す
# PARAMS: armature, out_prefix
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
rig = O[prm("armature", "Char_Armature")]; P = rig.pose.bones
H = char_height(); Y = body_center_y()
act = rig.animation_data.action if rig.animation_data else None
if rig.animation_data: rig.animation_data.action = None
LA = {}
def wq(name, axis, deg):
    Mr = P[name].bone.matrix_local.to_3x3()
    return Quaternion((Mr.inverted() @ Vector(axis)).normalized(), math.radians(deg))
for pb in P: pb.rotation_mode = 'QUATERNION'; pb.rotation_quaternion = (1, 0, 0, 0)
P["upper_arm.L"].rotation_quaternion = wq("upper_arm.L", (1, 0, 0), -40)
P["forearm.L"].rotation_quaternion = wq("forearm.L", (1, 0, 0), -50)
P["upper_arm.R"].rotation_quaternion = wq("upper_arm.R", (0, 1, 0), 25)
P["thigh.L"].rotation_quaternion = wq("thigh.L", (1, 0, 0), -45)
P["shin.L"].rotation_quaternion = wq("shin.L", (1, 0, 0), 70)
P["head"].rotation_quaternion = wq("head", (0, 0, 1), 25)
P["chest"].rotation_quaternion = wq("chest", (0, 0, 1), 12)
for pb in P:
    n = pb.name; fn = n.split("_")[0]
    if fn in ("index", "middle", "ring", "pinky", "thumb") and "_0" in n:
        seg = int(n.split("_")[1][:2]); s = n[-1]
        a = 0
        if s == "L" or fn in ("ring", "pinky"):
            a = {1: 70, 2: 80, 3: 60}[seg] if fn != "thumb" else {1: 20, 2: 30, 3: 30}[seg]
        pb.rotation_quaternion = Quaternion((1, 0, 0), math.radians(a))
for c in [c for pb in P for c in pb.constraints]: c.mute = True
out = render_views(prm("out_prefix"), [("a", 30, 8, 2.5 * H, 55), ("b", -60, 8, 2.5 * H, 55)], res=(700, 900),
                   target=(0, Y, 0.5 * H))
handsL = [o for o in ("Hand.L", "Hand.R", "Arm.L", "Arm.R") if o in O]
for s, sg in (("L", 1), ("R", -1)):
    hb = rig.matrix_world @ P[f"hand.{s}"].head if f"hand.{s}" in P else Vector((0.2 * H * sg, Y, 0.55 * H))
    out += render_views(f"{prm('out_prefix')}_hand{s}", [("f", 25 * sg, 5, 0.3 * H, 85), ("o", 90 * sg, 5, 0.3 * H, 85)],
                        visible=set(handsL), res=(500, 500), target=tuple(hb))
for c in [c for pb in P for c in pb.constraints]: c.mute = False
for pb in P: pb.rotation_quaternion = (1, 0, 0, 0)
if act: rig.animation_data.action = act
RESULT = str(out)
