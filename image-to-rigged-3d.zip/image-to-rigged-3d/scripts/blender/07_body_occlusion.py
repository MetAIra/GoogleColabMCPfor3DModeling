# 体パーツのうち「元モデルでは他パーツに隠れていた面」をレイで判定し、ボディスーツ色/肌色で塗り替える
# （服の下が補完生成された部分に、服や髪の色が写り込むのを防ぐ。シェーダーで混合）
# PARAMS:
#   body : "Body"
#   occluders : ["Hair","Coat","Skirt","Arm.L","Arm.R"]（存在するものだけ使う）
#   zones : [[z_min_ratio, z_max_ratio, [r,g,b]], ...]  身長比の高さ帯ごとの塗り色（先頭一致優先）
#           例: [[0.31,0.41,[0.92,0.68,0.60]]]（太もも=肌）。どこにも該当しない高さは default_color
#   default_color : [0.025,0.025,0.032]
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
import bmesh
from mathutils.bvhtree import BVHTree
H = char_height()
state = set_rest_pose()
dg = bpy.context.evaluated_depsgraph_get()
bm = bmesh.new()
for n in prm("occluders", ["Hair", "Coat", "Skirt", "Arm.L", "Arm.R"]):
    if n not in O: continue
    ob = O[n]; tmp = bmesh.new(); tmp.from_object(ob, dg); tmp.transform(ob.matrix_world)
    me = bpy.data.meshes.new("_tmp"); tmp.to_mesh(me); tmp.free(); bm.from_mesh(me); bpy.data.meshes.remove(me)
bvh = BVHTree.FromBMesh(bm); bm.free()
ob = O[prm("body", "Body")]; me = ob.data; W = ob.matrix_world; N3 = W.to_3x3().inverted().transposed()
zones = prm("zones", []); dflt = prm("default_color", [0.025, 0.025, 0.032])
occ = np.zeros(len(me.vertices), np.float32); fill = np.zeros((len(me.vertices), 4), np.float32)
for i, v in enumerate(me.vertices):
    p = W @ v.co; n = (N3 @ v.normal).normalized()
    t = n.orthogonal().normalized(); b2 = n.cross(t)
    hits = 0
    for d in [n] + [(n + 0.6 * a).normalized() for a in (t, -t, b2, -b2)]:
        if bvh.ray_cast(p + n * 0.0015 * H, d, 0.125 * H)[0] is not None: hits += 1
    occ[i] = 1.0 if hits >= 4 else (0.5 if hits == 3 else 0.0)
    col = dflt
    for z0, z1, c in zones:
        if z0 * H < p.z < z1 * H: col = c; break
    fill[i] = (*col, 1)
a1 = me.color_attributes.get("occl") or me.color_attributes.new("occl", 'FLOAT_COLOR', 'POINT')
c4 = np.repeat(occ[:, None], 4, 1); c4[:, 3] = 1; a1.data.foreach_set("color", c4.ravel())
a2 = me.color_attributes.get("occl_fill") or me.color_attributes.new("occl_fill", 'FLOAT_COLOR', 'POINT')
a2.data.foreach_set("color", fill.ravel())
mat = ob.active_material; Nn = mat.node_tree.nodes; L = mat.node_tree.links
bsdf = next(n for n in Nn if n.type == 'BSDF_PRINCIPLED')
ca = Nn.get("OcclAttr") or Nn.new('ShaderNodeVertexColor'); ca.name = "OcclAttr"; ca.layer_name = "occl"
fc = Nn.get("OcclFill") or Nn.new('ShaderNodeVertexColor'); fc.name = "OcclFill"; fc.layer_name = "occl_fill"
mix = Nn.get("OcclMix") or Nn.new('ShaderNodeMix'); mix.name = "OcclMix"; mix.data_type = 'RGBA'
L.new(Nn["T_color"].outputs['Color'], mix.inputs['A']); L.new(fc.outputs['Color'], mix.inputs['B'])
L.new(ca.outputs['Color'], mix.inputs['Factor']); L.new(mix.outputs['Result'], bsdf.inputs['Base Color'])
restore_pose(state)
RESULT = f"occluded frac {float((occ > 0.9).mean()):.3f}"
