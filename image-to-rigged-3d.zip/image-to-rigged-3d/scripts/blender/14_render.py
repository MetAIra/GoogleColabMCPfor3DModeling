# 14: 確認用の静止フレーム or 動画(MP4)を EEVEE でレンダー
# PARAMS:
#   mode   : "frames" | "video"
#   frames : [60,100,180,...]（mode=frames）
#   out    : 出力パス接頭辞（frames: scratchpad\seq, video: characters\<Name>\renders\<name>_action_）
#   res    : [720,960]
# RESULT: 出力パス
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
import os, time
SC.render.engine = 'BLENDER_EEVEE'
SC.render.resolution_x, SC.render.resolution_y = prm("res", [720, 960])
try: SC.eevee.taa_render_samples = prm("samples", 24)
except Exception: pass
for n in ("Floor",):
    if n in O: O[n].hide_render = True
ims = SC.render.image_settings
t = time.time(); out = []
if prm("mode", "frames") == "frames":
    try: ims.media_type = 'IMAGE'
    except Exception: pass
    ims.file_format = 'PNG'
    for f in prm("frames", [60, 100, 180, 200, 256, 271, 284, 340, 380, 405]):
        SC.frame_set(f); p = f"{prm('out')}_{f:03d}.png"; SC.render.filepath = p
        bpy.ops.render.render(write_still=True); out.append(p)
else:
    try: ims.media_type = 'VIDEO'
    except Exception: pass
    ims.file_format = 'FFMPEG'
    SC.render.ffmpeg.format = 'MPEG4'; SC.render.ffmpeg.codec = 'H264'; SC.render.ffmpeg.constant_rate_factor = 'HIGH'
    SC.render.filepath = prm("out"); os.makedirs(os.path.dirname(prm("out")), exist_ok=True)
    bpy.ops.render.render(animation=True); out.append(prm("out"))
RESULT = f"{time.time()-t:.0f}s {out}"
