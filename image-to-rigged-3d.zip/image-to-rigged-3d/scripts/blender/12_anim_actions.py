# 12: 手続き的アクション「立ち→歩き→走り→減速→ジャンプ→風を受けて立つ」(既定 420f/30fps) をキーフレーム化
# ワールド軸回転→ボーンローカル変換(wq)で、ボーンのロールに依存せず前後スイングを指定する。
# 符号: 脚/腕は X 軸マイナスで前へ、背骨は X 軸プラスで前傾、膝は X 軸プラスで曲がる（正面 -Y の場合）。
# PARAMS: armature（既定 "Char_Armature"）, speed_walk(1.3), speed_run(3.8)  ※H=2 基準、身長で自動スケール
# RESULT: 各区間の位置（13 の風の位置決めに使う）
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())

sc = SC
rig = O[prm("armature", "Char_Armature")]; S = char_height() / 2.0; P = rig.pose.bones
rig.animation_data_clear()
for pb in P:
    pb.rotation_mode = 'QUATERNION'; pb.rotation_quaternion = (1, 0, 0, 0); pb.location = (0, 0, 0)

FPS = 30; F0, F1 = 1, 420
sc.frame_start, sc.frame_end = F0, F1; sc.render.fps = FPS

LA = {}
def wq(name, axis, deg):
    """ワールド軸まわりの回転（レスト姿勢基準）をボーンローカルのクォータニオンへ変換"""
    if (name, axis) not in LA:
        Mr = P[name].bone.matrix_local.to_3x3()
        LA[(name, axis)] = (Mr.inverted() @ Vector(axis)).normalized()
    return Quaternion(LA[(name, axis)], math.radians(deg))

def ss(x):
    x = max(0.0, min(1.0, x)); return x * x * (3 - 2 * x)

def seg(f, a, b):
    return ss((f - a) / (b - a))

def weights(f):
    w_walk = seg(f, 20, 35) * (1 - seg(f, 140, 155))
    w_run = seg(f, 140, 155) * (1 - seg(f, 228, 248))
    return max(0.0, 1 - w_walk - w_run), w_walk, w_run

SPEED = {"walk": prm("speed_walk", 1.3) * S, "run": prm("speed_run", 3.8) * S}
FREQ = {"walk": 1.0, "run": 1.55}

# 位相とルート前進量を積分
phase = 0.0; ypos = 0.0; states = {}
for f in range(F0, F1 + 1):
    wi, ww, wr = weights(f)
    freq = ww * FREQ["walk"] + wr * FREQ["run"]
    spd = ww * SPEED["walk"] + wr * SPEED["run"]
    if 258 <= f <= 280:
        spd += 0.9 * S
    phase += freq / FPS; ypos -= spd / FPS
    states[f] = (phase, ypos, wi, ww, wr)

def pose_cycle(phi, kind):
    d = {}
    if kind == "walk":
        A_t, K_b, K_s, A_a, fore, lean, bob, tw = 22, 6, 48, 18, -14, 3, 0.022, 6
    else:
        A_t, K_b, K_s, A_a, fore, lean, bob, tw = 42, 18, 85, 38, -80, 11, 0.055, 10
    for side, ph in (("L", phi), ("R", phi + math.pi)):
        th = -A_t * math.sin(ph) - (8 if kind == "run" else 0)
        kn = K_b + K_s * max(0.0, math.cos(ph)) ** 1.5
        ft = -(th + kn) * 0.75 + (18 if kind == "run" else 12) * max(0.0, -math.sin(ph))
        d[f"thigh.{side}"] = th; d[f"shin.{side}"] = kn; d[f"foot.{side}"] = ft
        d[f"upper_arm.{side}"] = A_a * math.sin(ph); d[f"forearm.{side}"] = fore
    d["spine"] = lean * 0.5; d["chest"] = lean * 0.5; d["neck"] = -lean * 0.4; d["head"] = -lean * 0.4
    d["_twist_hips"] = tw * math.sin(phi); d["_twist_chest"] = -tw * 1.2 * math.sin(phi)
    d["_z"] = bob * math.cos(2 * phi) - (0.02 if kind == "walk" else 0.06)
    d["_x"] = -0.02 * math.cos(phi) * (1 if kind == "walk" else 0.5)
    d["_fist"] = 0.0 if kind == "walk" else 1.0
    return d

def pose_idle(f):
    t = f / FPS; br = math.sin(2 * math.pi * t / 3.2)
    d = {"chest": 1.2 * br, "head": -0.8 * br, "_z": 0.0, "_x": 0.0,
         "_twist_hips": 0.0, "_twist_chest": 0.0, "_fist": 0.0}
    for s in ("L", "R"):
        d[f"upper_arm.{s}"] = -4; d[f"forearm.{s}"] = -10
    if f >= 305:   # 風の区間: 風上へ少し前傾し、片腕で顔を守る
        w = seg(f, 305, 330)
        d["spine"] = 5 * w; d["chest"] = 3 * w; d["head"] = -6 * w - 0.8 * br
        d["upper_arm.R"] = -4 + (-75) * w; d["forearm.R"] = -10 + (-70) * w
    return d

JK = [
    (250, {}),
    (258, {"thigh.L": -55, "thigh.R": -55, "shin.L": 75, "shin.R": 75, "foot.L": -20, "foot.R": -20,
           "spine": 18, "chest": 8, "head": -15, "upper_arm.L": 45, "upper_arm.R": 45,
           "forearm.L": -20, "forearm.R": -20, "_z": -0.20}),
    (263, {"thigh.L": 5, "thigh.R": 5, "shin.L": 3, "shin.R": 3, "foot.L": 25, "foot.R": 25,
           "spine": -4, "chest": -4, "head": 0, "upper_arm.L": -130, "upper_arm.R": -130,
           "forearm.L": -10, "forearm.R": -10, "_z": 0.15}),
    (271, {"thigh.L": -45, "thigh.R": -35, "shin.L": 70, "shin.R": 55, "foot.L": 10, "foot.R": 10,
           "spine": 6, "chest": 2, "head": -4, "upper_arm.L": -70, "upper_arm.R": -70,
           "forearm.L": -30, "forearm.R": -30, "_z": 0.62}),
    (279, {"thigh.L": -25, "thigh.R": -25, "shin.L": 25, "shin.R": 25, "foot.L": 15, "foot.R": 15,
           "spine": 4, "chest": 2, "head": -2, "upper_arm.L": -40, "upper_arm.R": -40,
           "forearm.L": -20, "forearm.R": -20, "_z": 0.05}),
    (284, {"thigh.L": -50, "thigh.R": -50, "shin.L": 70, "shin.R": 70, "foot.L": -18, "foot.R": -18,
           "spine": 20, "chest": 8, "head": -14, "upper_arm.L": -25, "upper_arm.R": -25,
           "forearm.L": -35, "forearm.R": -35, "_z": -0.17}),
    (300, {}),
]

def jump_z(f):
    if f < 263: return None
    if f <= 279:   # 放物線（263: 0.15 → 271: 0.62 → 279: 0.05）
        t = (f - 263) / 16.0
        return 0.15 * (1 - t) + 0.05 * t + 0.52 * 4 * t * (1 - t)
    return None

def pose_jump(f):
    base = pose_idle(f)
    for (fa, ka), (fb, kb) in zip(JK, JK[1:]):
        if fa <= f <= fb:
            t = (f - fa) / (fb - fa)
            t = t if fa in (263, 271) else ss(t)
            d = dict(base)
            for k in set(ka) | set(kb):
                va = ka.get(k, base.get(k, 0.0)); vb = kb.get(k, base.get(k, 0.0))
                d[k] = va + (vb - va) * t
            jz = jump_z(f)
            if jz is not None: d["_z"] = jz
            return d
    return base

frames_data = {}; BONES = set()
for f in range(F0, F1 + 1):
    phase, ypos, wi, ww, wr = states[f]
    phi = 2 * math.pi * phase
    parts = [(wi, pose_idle(f))]
    if ww > 0: parts.append((ww, pose_cycle(phi, "walk")))
    if wr > 0: parts.append((wr, pose_cycle(phi, "run")))
    tot = sum(w for w, _ in parts)
    d = {}
    for w, p in parts:
        for k, v in p.items():
            d[k] = d.get(k, 0.0) + v * w / tot
    if 248 <= f <= 300:
        jw = seg(f, 248, 252) * (1 - seg(f, 296, 300))
        pj = pose_jump(f)
        for k in set(d) | set(pj):
            d[k] = d.get(k, 0.0) * (1 - jw) + pj.get(k, 0.0) * jw
    frames_data[f] = (d, ypos)
    BONES |= {k for k in d if not k.startswith("_")}

fingers = [pb for pb in P if pb.name.split("_")[0] in ("index", "middle", "ring", "pinky", "thumb") and "_0" in pb.name]
for f in range(F0, F1 + 1):
    d, ypos = frames_data[f]
    rig.location = (d.get("_x", 0.0) * S, ypos, d.get("_z", 0.0) * S); rig.keyframe_insert("location", frame=f)
    for b in BONES:
        if b in ("hips", "upper_chest"): continue
        P[b].rotation_quaternion = wq(b, (1, 0, 0), d.get(b, 0.0))
        P[b].keyframe_insert("rotation_quaternion", frame=f)
    P["hips"].rotation_quaternion = wq("hips", (0, 0, 1), d.get("_twist_hips", 0.0))
    P["hips"].keyframe_insert("rotation_quaternion", frame=f)
    P["upper_chest"].rotation_quaternion = wq("upper_chest", (0, 0, 1), d.get("_twist_chest", 0.0))
    P["upper_chest"].keyframe_insert("rotation_quaternion", frame=f)
    if f % 3 == 1 or f == F1:
        fist = d.get("_fist", 0.0)
        for pb in fingers:
            fn, rest = pb.name.split("_"); si = int(rest[:2])
            relax = {1: 15, 2: 20, 3: 15}[si] if fn != "thumb" else 5
            full = {1: 70, 2: 80, 3: 60}[si] if fn != "thumb" else {1: 20, 2: 30, 3: 30}[si]
            a = relax + (full - relax) * fist * 0.8
            pb.rotation_quaternion = Quaternion((1, 0, 0), math.radians(a))
            pb.keyframe_insert("rotation_quaternion", frame=f)

SC["anim_end_y"] = frames_data[F1][1]
RESULT = f"keyed bones={len(BONES)} y@140={frames_data[140][1]:.2f} y@250={frames_data[250][1]:.2f} final y={frames_data[F1][1]:.2f}"
