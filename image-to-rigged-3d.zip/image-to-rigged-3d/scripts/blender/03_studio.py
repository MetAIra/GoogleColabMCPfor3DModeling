# スタジオ照明・ワールド・ブルーム・シャドウキャッチャー床を作り、Cycles でヒーロー/正面/バストをレンダー
# PARAMS: out_dir, name, render(True/False), samples(256)
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
import os
H = char_height(); k = H / 2.0; name = prm("name", SC.get("char_name", "Char"))
for o in list(O):
    if o.type == 'LIGHT': bpy.data.objects.remove(o, do_unlink=True)
def area(n, loc, energy, color, size):
    ld = bpy.data.lights.new(n, 'AREA'); ld.energy = energy * k * k; ld.color = color; ld.size = size * k
    ob = bpy.data.objects.new(n, ld); SC.collection.objects.link(ob); ob.location = Vector(loc) * k
    ob.rotation_euler = (Vector((0, 0, H * 0.5)) - ob.location).to_track_quat('-Z', 'Y').to_euler()
area("Key", (2.0, -2.5, 2.6), 400, (1.0, 0.97, 0.95), 1.5)
area("Fill", (-2.5, -2.0, 1.4), 150, (0.85, 0.9, 1.0), 2.0)
area("Rim", (0.5, 3.0, 2.4), 500, (0.5, 0.75, 1.0), 1.5)
w = SC.world or bpy.data.worlds.new("World"); SC.world = w; w.use_nodes = True
bg = next(n for n in w.node_tree.nodes if n.type == 'BACKGROUND')
bg.inputs['Color'].default_value = (0.02, 0.025, 0.04, 1); bg.inputs['Strength'].default_value = 1.0
try:
    if 'AgX' in [i.identifier for i in SC.view_settings.bl_rna.properties['view_transform'].enum_items]:
        SC.view_settings.view_transform = 'AgX'
except Exception: pass
# ブルーム（Blender 5.x のコンポジターノードグループ）
try:
    ng = bpy.data.node_groups.get("Char_Comp") or bpy.data.node_groups.new("Char_Comp", 'CompositorNodeTree')
    for n in list(ng.nodes): ng.nodes.remove(n)
    rl = ng.nodes.new('CompositorNodeRLayers'); gl = ng.nodes.new('CompositorNodeGlare')
    if not any(getattr(s, 'in_out', '') == 'OUTPUT' for s in ng.interface.items_tree):
        ng.interface.new_socket("Image", in_out='OUTPUT', socket_type='NodeSocketColor')
    go = ng.nodes.new('NodeGroupOutput')
    ng.links.new(rl.outputs['Image'], gl.inputs['Image']); ng.links.new(gl.outputs['Image'], go.inputs[0])
    gl.inputs['Type'].default_value = 'Bloom'; gl.inputs['Quality'].default_value = 'High'
    gl.inputs['Threshold'].default_value = 2.5; gl.inputs['Strength'].default_value = 0.5; gl.inputs['Size'].default_value = 0.5
    SC.compositing_node_group = ng; SC.render.use_compositing = True
except Exception as e:
    print("bloom skipped", e)
fl = O.get("Floor")
if not fl:
    import bmesh
    me = bpy.data.meshes.new("Floor"); bm = bmesh.new()
    bmesh.ops.create_circle(bm, cap_ends=True, radius=3 * k, segments=64); bm.to_mesh(me); bm.free()
    fl = bpy.data.objects.new("Floor", me); SC.collection.objects.link(fl)
fl.is_shadow_catcher = True
out = []
if prm("render", True):
    od = prm("out_dir"); os.makedirs(od, exist_ok=True)
    SC.render.engine = 'CYCLES'; SC.cycles.device = 'GPU'; SC.cycles.samples = prm("samples", 256); SC.cycles.use_denoising = True
    out = render_views(os.path.join(od, name), [("hero_34", 30, 8, 3.1 * H, 85), ("front", 0, 3, 3.1 * H, 85)],
                       engine='CYCLES', res=(1200, 1600), target=(0, 0, H * 0.5))
    out += render_views(os.path.join(od, name), [("bust", 20, 4, 1.3 * H, 85)], engine='CYCLES', res=(1200, 1600),
                        target=(0, 0, H * 0.78))
RESULT = f"studio ok {out}"
