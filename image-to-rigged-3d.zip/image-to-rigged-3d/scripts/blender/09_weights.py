# パーツごとに「関係するボーンだけ」を変形ボーンにして自動ウェイト（ボーンヒート）を付ける
# PARAMS:
#   armature : 既定 "Char_Armature"
#   rigid    : {"Chest_Acc": "upper_chest"} 小物を1本のボーンに剛体追従させる
#   extra_sets : {"<パーツ名>": ["bone", ...]} 追加/上書きのボーン集合（任意）
# RESULT: (パーツ, 頂点グループ数, 無ウェイト頂点数, 総頂点数)
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
rig = O[prm("armature", "Char_Armature")]; arm = rig.data
allb = [b.name for b in arm.bones]
def pick(*pre): return {n for n in allb if n.startswith(pre)}
torso = {"hips", "spine", "chest", "upper_chest"}
SETS = {
    "Body": torso | {"neck", "shoulder.L", "shoulder.R"} | pick("thigh.", "shin.", "foot.", "toe."),
    "Arm.L": {"shoulder.L", "upper_arm.L", "forearm.L", "hand.L"},
    "Arm.R": {"shoulder.R", "upper_arm.R", "forearm.R", "hand.R"},
    "Hair": pick("hair_") | {"head", "neck"},
    "Coat": pick("coat_") | torso | {"shoulder.L", "shoulder.R"},
    "Skirt": pick("skirt.") | torso | {"neck", "thigh.L", "thigh.R"},
    "Boot.L": {"shin.L", "foot.L", "toe.L"},
    "Boot.R": {"shin.R", "foot.R", "toe.R"},
}
SETS.update({k: set(v) for k, v in (prm("extra_sets", {}) or {}).items()})
state = set_rest_pose()
log = []
for name, bones in SETS.items():
    if name not in O: continue
    ob = O[name]; ob.hide_set(False)
    ob.parent = None
    for m in [m for m in ob.modifiers if m.type == 'ARMATURE']: ob.modifiers.remove(m)
    ob.vertex_groups.clear()
    for b in arm.bones: b.use_deform = b.name in bones
    bpy.ops.object.select_all(action='DESELECT'); ob.select_set(True); rig.select_set(True)
    bpy.context.view_layer.objects.active = rig
    bpy.ops.object.parent_set(type='ARMATURE_AUTO')
    unw = sum(1 for v in ob.data.vertices if not any(g.weight > 1e-4 for g in v.groups))
    log.append((name, len(ob.vertex_groups), unw, len(ob.data.vertices)))
for name, bn in (prm("rigid", {}) or {}).items():
    if name not in O: continue
    ob = O[name]; ob.vertex_groups.clear()
    vg = ob.vertex_groups.new(name=bn); vg.add(range(len(ob.data.vertices)), 1.0, 'REPLACE')
    if not any(m.type == 'ARMATURE' for m in ob.modifiers):
        m = ob.modifiers.new("Armature", 'ARMATURE'); m.object = rig
    ob.parent = rig
    log.append((name, "rigid->" + bn))
for b in arm.bones: b.use_deform = b.name != "root"
restore_pose(state)
RESULT = str(log)
