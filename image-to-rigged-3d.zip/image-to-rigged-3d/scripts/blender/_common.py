# Blender スクリプト共通ヘルパー（各スクリプト冒頭で exec される）
# 呼び出し側の globals に PARAMS(dict) と SKILL(スキルのルートパス) が入っている前提。
import bpy, math, numpy as np
from mathutils import Vector, Matrix, Quaternion

PARAMS = globals().get("PARAMS", {}) or {}
O = bpy.data.objects
SC = bpy.context.scene

def prm(key, default=None):
    return PARAMS.get(key, default)

def verts_world(name):
    """オブジェクトの頂点をワールド座標の (N,3) numpy 配列で返す（モディファイア未適用のメッシュ）"""
    ob = O[name]; me = ob.data
    a = np.empty(len(me.vertices) * 3, np.float32); me.vertices.foreach_get("co", a)
    a = a.reshape(-1, 3); M = np.array(ob.matrix_world)
    return a @ M[:3, :3].T + M[:3, 3]

def ensure_collection(name):
    c = bpy.data.collections.get(name) or bpy.data.collections.new(name)
    if c.name not in SC.collection.children:
        SC.collection.children.link(c)
    return c

def link_only(ob, col):
    for c in list(ob.users_collection):
        c.objects.unlink(ob)
    col.objects.link(ob)

def char_height():
    return float(SC.get("char_height", 2.0))

def body_center_y():
    return float(SC.get("char_center_y", 0.0))

def look_at(cam, target):
    cam.rotation_euler = (Vector(target) - cam.location).to_track_quat('-Z', 'Y').to_euler()

def render_views(prefix, views, visible=None, engine='BLENDER_EEVEE', res=(600, 800), color_type='TEXTURE',
                 target=None, transparent=False):
    """views: [(tag, azimuth_deg, elevation_deg, distance, lens)]。target 既定は (0, center_y, H/2)。
    visible: 表示するメッシュ/カーブ名の集合（None なら現状のまま）。戻り値: 出力パスのリスト"""
    H = char_height(); cy = body_center_y()
    tgt = Vector(target) if target else Vector((0, cy, H * 0.5))
    cd = bpy.data.cameras.get("SkillCam") or bpy.data.cameras.new("SkillCam")
    cam = O.get("SkillCam") or bpy.data.objects.new("SkillCam", cd)
    if cam.name not in SC.collection.objects: SC.collection.objects.link(cam)
    prev_cam, prev_engine = SC.camera, SC.render.engine
    prev_res = (SC.render.resolution_x, SC.render.resolution_y)
    vis = {o.name: o.hide_render for o in SC.objects}
    if visible is not None:
        for o in SC.objects:
            if o.type in ('MESH', 'CURVE'): o.hide_render = o.name not in visible
    SC.camera = cam; SC.render.engine = engine
    SC.render.resolution_x, SC.render.resolution_y = res
    SC.render.film_transparent = transparent
    ims = SC.render.image_settings
    try: ims.media_type = 'IMAGE'
    except Exception: pass
    ims.file_format = 'PNG'
    ims.color_mode = 'RGBA' if transparent else 'RGB'
    if engine == 'BLENDER_WORKBENCH':
        sh = SC.display.shading; sh.light = 'STUDIO'; sh.color_type = color_type
        sh.single_color = (0.8, 0.8, 0.8); sh.show_cavity = True; sh.show_xray = False
    out = []
    for tag, az, el, dist, lens in views:
        cd.lens = lens
        r, e = math.radians(az), math.radians(el)
        cam.location = tgt + Vector((dist * math.cos(e) * math.sin(r), -dist * math.cos(e) * math.cos(r), dist * math.sin(e)))
        look_at(cam, tgt)
        p = f"{prefix}_{tag}.png"; SC.render.filepath = p
        bpy.ops.render.render(write_still=True); out.append(p)
    for o in SC.objects:
        if o.name in vis: o.hide_render = vis[o.name]
    SC.camera, SC.render.engine = prev_cam, prev_engine
    SC.render.resolution_x, SC.render.resolution_y = prev_res
    SC.render.film_transparent = False
    return out

def set_rest_pose(mute_constraints=True):
    """ベイク等のためにリグをレスト姿勢へ（戻すときは restore_pose(state)）"""
    rig = O.get(prm("armature", "Char_Armature"))
    if not rig: return None
    state = dict(loc=rig.location.copy(), rot=rig.rotation_euler.copy(), act=rig.animation_data.action if rig.animation_data else None)
    if rig.animation_data: rig.animation_data.action = None
    rig.location = (0, 0, 0); rig.rotation_euler = (0, 0, 0)
    for pb in rig.pose.bones:
        pb.location = (0, 0, 0); pb.rotation_quaternion = (1, 0, 0, 0); pb.rotation_euler = (0, 0, 0)
        for c in pb.constraints: c.mute = mute_constraints
    bpy.context.view_layer.update()
    return state

def restore_pose(state):
    rig = O.get(prm("armature", "Char_Armature"))
    if not rig or state is None: return
    for pb in rig.pose.bones:
        for c in pb.constraints: c.mute = False
    if state["act"] is not None:
        rig.animation_data_create(); rig.animation_data.action = state["act"]
    rig.location = state["loc"]; rig.rotation_euler = state["rot"]
