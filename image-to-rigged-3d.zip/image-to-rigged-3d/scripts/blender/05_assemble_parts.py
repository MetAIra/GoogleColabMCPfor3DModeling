# パーツをグループ化して最終パーツを作る（複製→結合→減面→重複頂点除去→小破片除去→法線再計算）
# PARAMS:
#   groups : {"Hair": ["Q02","P01"], "Body": ["P03"], "Arm.L": [...], "Arm.R": [...], "Coat": [...],
#             "Skirt": [...], "Boot.L": [...], "Boot.R": [...], "<任意の小物名>": [...]}
#            ※ .L/.R はキャラ基準（Blender の +X 側 = キャラの左）。RESULT の cx で確認すること
#   targets: {"Hair":120000,"Body":60000,"Arm.L":30000,"Arm.R":30000,"Coat":60000,"Skirt":50000}（省略分は減面なし）
#   collection: 最終パーツのコレクション名（既定 "Char_Parts"）
# RESULT: (名前, 面数, 中心x, 除去破片数)
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
import bmesh
col = ensure_collection(prm("collection", "Char_Parts"))
targets = prm("targets", {"Hair": 120000, "Body": 60000, "Arm.L": 30000, "Arm.R": 30000, "Coat": 60000, "Skirt": 50000})
info = []
for gname, srcs in prm("groups").items():
    if gname in O: bpy.data.objects.remove(O[gname], do_unlink=True)
    objs = []
    for s in srcs:
        o = O[s]; c = o.copy(); c.data = o.data.copy(); col.objects.link(c); c.hide_set(False); c.hide_render = False
        objs.append(c)
    bpy.ops.object.select_all(action='DESELECT')
    for c in objs: c.select_set(True)
    bpy.context.view_layer.objects.active = objs[0]
    if len(objs) > 1: bpy.ops.object.join()
    ob = bpy.context.view_layer.objects.active; ob.name = gname; ob.data.name = gname
    t = targets.get(gname)
    if t and len(ob.data.polygons) > t:
        m = ob.modifiers.new("Dec", 'DECIMATE'); m.ratio = t / len(ob.data.polygons)
        with bpy.context.temp_override(object=ob, active_object=ob):
            bpy.ops.object.modifier_apply(modifier=m.name)
    bm = bmesh.new(); bm.from_mesh(ob.data)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=1e-5)
    bm.verts.ensure_lookup_table(); seen = set(); comps = []
    for v in bm.verts:
        if v.index in seen: continue
        st = [v]; seen.add(v.index); comp = [v]
        while st:
            x = st.pop()
            for e in x.link_edges:
                y = e.other_vert(x)
                if y.index not in seen: seen.add(y.index); st.append(y); comp.append(y)
        comps.append(comp)
    small = [c for c in comps if len(c) < max(30, len(bm.verts) * 0.002)]
    bmesh.ops.delete(bm, geom=[v for c in small for v in c], context='VERTS')
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(ob.data); bm.free()
    for p in ob.data.polygons: p.use_smooth = True
    cx = float(verts_world(gname)[:, 0].mean())
    info.append((gname, len(ob.data.polygons), round(cx, 3), len(small)))
for c in bpy.data.collections:
    if c.name.startswith("Parts_"):
        for o in c.objects: o.hide_set(True); o.hide_render = True
nm = SC.get("char_name", "Char")
for n in (nm, f"{nm}_highpoly"):
    if n in O: O[n].hide_set(True); O[n].hide_render = True
if "Body" in O:
    SC["char_center_y"] = float(np.median(verts_world("Body")[:, 1]))
RESULT = str(info)
