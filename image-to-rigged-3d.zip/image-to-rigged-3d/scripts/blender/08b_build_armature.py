# 08b: 08a のランドマークから人型アーマチュア＋揺れものチェーン（髪/スカート/コート）を作る
# PARAMS:
#   armature    : 作成するアーマチュア名（既定 "Char_Armature"）
#   hair_chains : True/False（既定 True）
#   overrides   : {"hip_z":0.9, "arm.L.wrist":[x,y,z], ...} ランドマークの手動上書き（任意）
# RESULT: チェーン一覧, ボーン数
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
import json
H = char_height(); B = verts_world("Body")
F = json.loads(SC["landmarks_full"])
for k, v in (prm("overrides", {}) or {}).items():
    if k.startswith("arm."):
        _, s, kk = k.split("."); F["arm"][s][kk] = v
    else:
        F[k] = v
Y = F["Y"]; hip_z = F["hip_z"]; knee_z = F["knee_z"]; ankle_z = F["ankle_z"]; neck_top = F["neck_top"]; sp = F["sp"]
ARM = {s: {k: (Vector(v) if isinstance(v, list) else v) for k, v in F["arm"][s].items()} for s in ("L", "R")}
def leg_point(side, z):
    key = {hip_z: "hip", knee_z: "knee"}.get(z, "ankle")
    return Vector(F["leg"][side][key])
def toe_y(side):
    return F["leg"][side]["toe_y"]
# ---- アーマチュア作成 ----
an = prm("armature", "Char_Armature")
if an in O: bpy.data.objects.remove(O[an], do_unlink=True)
arm = bpy.data.armatures.new(an); rig = bpy.data.objects.new(an, arm)
col = bpy.data.collections.get(prm("collection", "Char_Parts")) or SC.collection
col.objects.link(rig); rig.show_in_front = True; arm.display_type = 'STICK'
bpy.ops.object.select_all(action='DESELECT'); bpy.context.view_layer.objects.active = rig; rig.select_set(True)
bpy.ops.object.mode_set(mode='EDIT'); E = arm.edit_bones
def bone(n, h, t, parent=None, connect=False):
    b = E.new(n); b.head = Vector(h); b.tail = Vector(t)
    if parent: b.parent = E[parent]; b.use_connect = connect
    return b
bone("root", (0, Y, 0), (0, Y + 0.15 * H, 0))
bone("hips", (0, Y, sp["hips"]), (0, Y, sp["spine"]), "root")
bone("spine", (0, Y, sp["spine"]), (0, Y, sp["chest"]), "hips", True)
bone("chest", (0, Y, sp["chest"]), (0, Y, sp["upper"]), "spine", True)
bone("upper_chest", (0, Y, sp["upper"]), (0, Y, sp["neck"]), "chest", True)
bone("neck", (0, Y, sp["neck"]), (0, Y, neck_top), "upper_chest", True)
bone("head", (0, Y, neck_top), (0, Y, neck_top + 0.17 * H), "neck", True)
for s, g in (("L", 1), ("R", -1)):
    a = ARM[s]
    bone(f"shoulder.{s}", (0.01 * H * g, Y, a["shoulder"].z - 0.015 * H), a["shoulder"], "upper_chest")
    bone(f"upper_arm.{s}", a["shoulder"], a["elbow"], f"shoulder.{s}", True)
    bone(f"forearm.{s}", a["elbow"], a["wrist"], f"upper_arm.{s}", True)
    bone(f"hand.{s}", a["wrist"], a["tip"], f"forearm.{s}", True)
    hp_, kp, ap = leg_point(s, hip_z), leg_point(s, knee_z), leg_point(s, max(ankle_z, float(B[:, 2].min()) + 0.005 * H))
    ap.z = ankle_z
    ty = toe_y(s)
    bone(f"thigh.{s}", hp_, kp, "hips")
    bone(f"shin.{s}", kp, ap, f"thigh.{s}", True)
    ft = Vector((ap.x, 0.7 * ty + 0.3 * ap.y, 0.015 * H))
    bone(f"foot.{s}", ap, ft, f"shin.{s}", True)
    bone(f"toe.{s}", ft, (ap.x, ty, 0.01 * H), f"foot.{s}", True)
# ---- 揺れものチェーン ----
chains = {}
def chain(prefix, pts, parent):
    prev = parent
    for i in range(len(pts) - 1):
        b = bone(f"{prefix}.{i+1:02d}", pts[i], pts[i + 1], prev, i > 0); prev = b.name
    chains[prefix] = len(pts) - 1
if prm("hair_chains", True) and "Hair" in O:
    Hh = verts_world("Hair")
    specs = {"hair_back.C": (-0.05, 0.05, 0.07), "hair_back.L": (0.05, 0.15, 0.03), "hair_back.R": (-0.15, -0.05, 0.03),
             "hair_side.L": (0.15, 0.35, -0.12), "hair_side.R": (-0.35, -0.15, -0.12)}
    zs = np.linspace(sp["neck"] + 0.03 * H, float(Hh[:, 2].min()) + 0.06 * H, 7)
    for nm, (x0, x1, yo) in specs.items():
        pts = []
        for z in zs:
            m = (Hh[:, 0] > x0 * H) & (Hh[:, 0] < x1 * H) & (np.abs(Hh[:, 2] - z) < 0.02 * H) & (Hh[:, 1] > Y + yo * H)
            if m.sum() > 30: pts.append(tuple(Hh[m].mean(0)))
            else: break
        if len(pts) >= 3: chain(nm, pts, "head")
def sector_chain(V, th, zmin, zmax, nseg, cos_thr):
    d = np.array([math.sin(math.radians(th)), -math.cos(math.radians(th))])
    Wv = V[(V[:, 2] > zmin) & (V[:, 2] < zmax)]
    rel = Wv[:, :2] - np.array([0, Y]); r = np.linalg.norm(rel, axis=1)
    Wv = Wv[(rel @ d) / (r + 1e-6) > cos_thr]
    if len(Wv) < 50: return None
    z0, z1 = np.percentile(Wv[:, 2], 97), np.percentile(Wv[:, 2], 2)
    if z0 - z1 < 0.04 * H: return None
    pts = []
    for z in np.linspace(z0, z1, nseg + 1):
        sl = Wv[np.abs(Wv[:, 2] - z) < 0.0125 * H]
        if len(sl) < 5: return None
        rr = np.linalg.norm(sl[:, :2] - [0, Y], axis=1)
        pts.append(tuple(sl[rr > np.percentile(rr, 50)].mean(0)))
    return pts
if "Skirt" in O:
    S = verts_world("Skirt")
    for kk in range(8):
        p = sector_chain(S, 360 * kk / 8, hip_z - 0.1 * H, hip_z + 0.06 * H, 2, 0.93)
        if p: chain(f"skirt.{kk}", p, "hips")
if "Coat" in O:
    C = verts_world("Coat")
    for nm, th in [("coat_side.L", 90), ("coat_side.R", -90), ("coat_back.L", 145), ("coat_back.R", -145)]:
        p = sector_chain(C, th, hip_z - 0.1 * H, sp["spine"] + 0.07 * H, 3, 0.9)
        if p: chain(nm, p, "spine")
    for s, g in (("L", 1), ("R", -1)):   # 前端（開いたコートの前身頃）
        Wv = C[(C[:, 0] * g > 0.06 * H) & (C[:, 0] * g < 0.16 * H) & (C[:, 1] < Y - 0.02 * H) &
               (C[:, 2] < sp["spine"] + 0.07 * H) & (C[:, 2] > hip_z - 0.1 * H)]
        if len(Wv) > 50:
            z0, z1 = np.percentile(Wv[:, 2], 97), np.percentile(Wv[:, 2], 2)
            pts = []
            for z in np.linspace(z0, z1, 4):
                sl = Wv[np.abs(Wv[:, 2] - z) < 0.015 * H]
                if len(sl): pts.append(tuple(sl.mean(0)))
            if len(pts) == 4 and z0 - z1 > 0.04 * H: chain(f"coat_front.{s}", pts, "spine")
bpy.ops.object.mode_set(mode='OBJECT')
for b in arm.bones: b.use_deform = b.name != "root"
for pb in rig.pose.bones: pb.rotation_mode = 'QUATERNION'
RESULT = json.dumps(dict(chains=chains, bones=len(arm.bones)))
