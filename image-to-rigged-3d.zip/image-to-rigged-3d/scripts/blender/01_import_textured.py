# テクスチャ付きメッシュ(OBJ+PBR)と高ポリ(GLB)を読み込み、足元を z=0 に揃え、PBR＋発光マテリアルを組む
# PARAMS:
#   tex_dir      : textured_mesh.obj / textured_mesh.jpg / _metallic.jpg / _roughness.jpg のあるフォルダ
#   highpoly_glb : 採用シードの shape_sXXXX.glb（法線ベイク・パーツ分解の基準）
#   name         : キャラ名（オブジェクト名の接頭辞, 例 "AIra"）
#   rough_remap  : [min,max] ラフネス再マップ（アニメ調は [0.4,0.85]）
#   emission     : {"hue":[0.47,0.61], "sat":0.45, "val":0.55, "strength":6} または None（発光色の自動抽出）
#   remove_compare : True なら Compare コレクションを削除
# RESULT: 面数, bbox, 身長
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
import os
name = prm("name", "Char"); D = prm("tex_dir")
if prm("remove_compare", True) and bpy.data.collections.get("Compare"):
    c = bpy.data.collections["Compare"]
    for o in list(c.objects): bpy.data.objects.remove(o, do_unlink=True)
    bpy.data.collections.remove(c)
for o in list(O):
    if o.name == "Cube": bpy.data.objects.remove(o, do_unlink=True)
col = ensure_collection(f"{name}_Source")
before = set(O)
bpy.ops.wm.obj_import(filepath=os.path.join(D, "textured_mesh.obj"))
lp = [o for o in O if o not in before][0]; lp.name = name; link_only(lp, col)
before = set(O)
bpy.ops.import_scene.gltf(filepath=prm("highpoly_glb"))
hp = None
for o in [o for o in O if o not in before]:
    if o.type == 'MESH': hp = o; o.name = f"{name}_highpoly"; link_only(o, col)
    else: bpy.data.objects.remove(o, do_unlink=True)
# 足元を z=0 へ
bpy.context.view_layer.update()
zmin = min((lp.matrix_world @ Vector(c)).z for c in lp.bound_box)
for ob in (lp, hp):
    if ob: ob.location.z -= zmin
bpy.context.view_layer.update()
bb = [lp.matrix_world @ Vector(c) for c in lp.bound_box]
H = max(v.z for v in bb) - min(v.z for v in bb)
SC["char_height"] = H; SC["char_name"] = name
# マテリアル
mat = bpy.data.materials.new(f"{name}_PBR"); mat.use_nodes = True
N = mat.node_tree.nodes; L = mat.node_tree.links
bsdf = next(n for n in N if n.type == 'BSDF_PRINCIPLED')
def tex(fn, cs, loc):
    t = N.new('ShaderNodeTexImage'); t.location = loc
    t.image = bpy.data.images.load(os.path.join(D, fn), check_existing=True); t.image.colorspace_settings.name = cs
    return t
alb = tex("textured_mesh.jpg", 'sRGB', (-700, 300)); alb.name = "T_albedo"
met = tex("textured_mesh_metallic.jpg", 'Non-Color', (-700, 0))
rough = tex("textured_mesh_roughness.jpg", 'Non-Color', (-700, -300))
L.new(alb.outputs['Color'], bsdf.inputs['Base Color'])
L.new(met.outputs['Color'], bsdf.inputs['Metallic'])
rr = prm("rough_remap", [0.4, 0.85])
mr = N.new('ShaderNodeMapRange'); mr.location = (-350, -300)
mr.inputs['To Min'].default_value, mr.inputs['To Max'].default_value = rr
L.new(rough.outputs['Color'], mr.inputs['Value']); L.new(mr.outputs['Result'], bsdf.inputs['Roughness'])
bsdf.inputs['Specular IOR Level'].default_value = 0.35
em = prm("emission", {"hue": [0.47, 0.61], "sat": 0.45, "val": 0.55, "strength": 6})
if em:
    sep = N.new('ShaderNodeSeparateColor'); sep.mode = 'HSV'; L.new(alb.outputs['Color'], sep.inputs['Color'])
    def band(inp, a, b, rev=False):
        m = N.new('ShaderNodeMapRange'); m.interpolation_type = 'SMOOTHSTEP'
        m.inputs['From Min'].default_value, m.inputs['From Max'].default_value = (b, a) if rev else (a, b)
        L.new(inp, m.inputs['Value']); return m.outputs['Result']
    def mul(a, b):
        m = N.new('ShaderNodeMath'); m.operation = 'MULTIPLY'; L.new(a, m.inputs[0])
        if isinstance(b, float): m.inputs[1].default_value = b
        else: L.new(b, m.inputs[1])
        return m.outputs['Value']
    h0, h1 = em["hue"]
    hm = mul(band(sep.outputs['Red'], h0, h0 + 0.03), band(sep.outputs['Red'], h1 - 0.03, h1, rev=True))
    m = mul(mul(hm, band(sep.outputs['Green'], em["sat"], em["sat"] + 0.2)), band(sep.outputs['Blue'], em["val"], em["val"] + 0.2))
    L.new(alb.outputs['Color'], bsdf.inputs['Emission Color'])
    L.new(mul(m, float(em["strength"])), bsdf.inputs['Emission Strength'])
lp.data.materials.clear(); lp.data.materials.append(mat)
for p in lp.data.polygons: p.use_smooth = True
if hp: hp.hide_set(True); hp.hide_render = True
RESULT = f"lowpoly {len(lp.data.polygons)} faces, highpoly {len(hp.data.polygons) if hp else 0}, H={H:.3f}"
