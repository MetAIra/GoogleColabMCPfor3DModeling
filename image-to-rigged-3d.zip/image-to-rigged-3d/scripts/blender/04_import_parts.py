# X-Part の出力（part_XX.glb）を読み込み、1パーツずつ単体レンダーして識別用シートを作る
# PARAMS:
#   part_dir : part_XX.glb のフォルダ
#   prefix   : オブジェクト名の接頭辞（1段目 "P", 2段目 "Q", 3段目 "R" など）
#   z_offset : 01 で足元を z=0 に移動した量（= 元の zmin の符号反転。scene["z_offset"] に保存済みなら省略可）
#   out_prefix : 単体レンダー画像の接頭辞（scratchpad）
# RESULT: 各パーツの名前, 面数, 中心x, z範囲, 画像パス
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
import os, glob
D = prm("part_dir"); pre = prm("prefix", "P")
name = SC.get("char_name", "Char")
src = O.get(name)
# 足元補正量: 元メッシュ(高ポリ)の位置から推定
zoff = prm("z_offset", None)
if zoff is None:
    hp = O.get(f"{name}_highpoly"); zoff = hp.location.z if hp else 0.0
col = ensure_collection(f"Parts_{pre}")
files = sorted(glob.glob(os.path.join(D, "part_*.glb")))
info = []
for f in files:
    i = int(os.path.basename(f)[5:7])
    before = set(O)
    bpy.ops.import_scene.gltf(filepath=f)
    for o in [o for o in O if o not in before]:
        if o.type != 'MESH':
            bpy.data.objects.remove(o, do_unlink=True); continue
        link_only(o, col); o.name = f"{pre}{i:02d}"; o.location.z += zoff
        o.hide_set(False)
bpy.context.view_layer.update()
shots = []
for o in sorted(col.objects, key=lambda x: x.name):
    V = verts_world(o.name)
    info.append((o.name, len(o.data.polygons), round(float(V[:, 0].mean()), 3),
                 [round(float(V[:, 2].min()), 2), round(float(V[:, 2].max()), 2)]))
    H = char_height()
    shots += render_views(f"{prm('out_prefix')}_{o.name}", [("a", 25, 10, 2.6 * H, 50), ("b", 200, 10, 2.6 * H, 50)],
                          visible={o.name}, engine='BLENDER_WORKBENCH', res=(400, 560), color_type='SINGLE',
                          target=(0, 0, H * 0.5))
for o in col.objects: o.hide_set(True)
RESULT = f"{info} | images: {len(shots)}"
