# 手の作り直し: AI 生成の「ミトン状の手」を削除し、Skin モディファイアで5本指の手を作って指ボーン(3本×5)と自動ウェイトを付ける
# 前提: 08a で Arm.L/R に "tipdist" 属性と手首/手先ランドマークがある。手のひらは前(-Y)向き・指は下向きの A ポーズ想定
# PARAMS:
#   armature : 既定 "Char_Armature"
#   glove    : True なら手のひら〜指の付け根を手袋色に（既定 True）
#   skin_color / glove_color / band_color : [r,g,b]
#   scale    : 手の大きさ倍率（既定 1.15。H=2 のキャラで手長 ≈ 0.12）
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
import bmesh, json
H = char_height(); K = prm("scale", 1.15) * H / 2.0
rig = O[prm("armature", "Char_Armature")]; arm = rig.data
F = json.loads(SC["landmarks_full"])
col = bpy.data.collections.get(prm("collection", "Char_Parts")) or SC.collection
state = set_rest_pose()
FING = {  # knuckle_x, knuckle_y, splay, segs, radius（ローカル: x=親指側+, y=指先方向, z=手の甲側）
    "index":  (0.0150, 0.048, 6, (0.020, 0.013, 0.011), 0.0080),
    "middle": (0.0050, 0.050, 1, (0.023, 0.015, 0.012), 0.0082),
    "ring":   (-0.0055, 0.048, -4, (0.021, 0.014, 0.011), 0.0078),
    "pinky":  (-0.0150, 0.044, -9, (0.016, 0.011, 0.009), 0.0070),
}
CURL = (12, 16, 12)
THUMB = [Vector((0.010, 0.008, -0.006)), Vector((0.022, 0.022, -0.012)), Vector((0.029, 0.036, -0.016)), Vector((0.032, 0.048, -0.018))]
def finger_pts(kx, ky, splay, segs):
    pts = [Vector((kx, ky, 0))]; ang = 0.0; p = pts[0].copy()
    dv0 = Vector((math.sin(math.radians(splay)), math.cos(math.radians(splay)), 0))
    for L_, c in zip(segs, CURL):
        ang += math.radians(c)
        p = p + Vector((dv0.x * math.cos(ang), dv0.y * math.cos(ang), -math.sin(ang))) * L_; pts.append(p.copy())
    return pts
def mk(name, color, rough=0.5, emit=None, sss=0.0):
    m = bpy.data.materials.get(name) or bpy.data.materials.new(name); m.use_nodes = True
    b = next(n for n in m.node_tree.nodes if n.type == 'BSDF_PRINCIPLED')
    b.inputs['Base Color'].default_value = (*color, 1); b.inputs['Roughness'].default_value = rough
    b.inputs['Specular IOR Level'].default_value = 0.35
    b.inputs['Emission Strength'].default_value = 4.0 if emit else 0.0
    if emit: b.inputs['Emission Color'].default_value = (*emit, 1)
    if sss: b.inputs['Subsurface Weight'].default_value = sss; b.inputs['Subsurface Radius'].default_value = (1.0, 0.4, 0.3)
    return m
skin = mk("M_Skin", prm("skin_color", [0.92, 0.68, 0.60]), 0.55, sss=0.15)
glove = mk("M_Glove", prm("glove_color", [0.02, 0.02, 0.025]), 0.45)
band = mk("M_WristBand", prm("band_color", [0.1, 0.7, 1.0]), 0.3, emit=prm("band_color", [0.15, 0.75, 1.0]))
info = {}
for s in ("L", "R"):
    A = F["arm"][s]; W = Vector(A["wrist"]); TIP = Vector(A["tip"])
    # 1) ミトン削除＋袖の穴埋め
    am = O[f"Arm.{s}"].data
    td = [d.value for d in am.attributes["tipdist"].data]
    bm = bmesh.new(); bm.from_mesh(am); bm.verts.ensure_lookup_table()
    bmesh.ops.delete(bm, geom=[bm.verts[i] for i, d in enumerate(td) if d < A["wrist_d"]], context='VERTS')
    bmesh.ops.holes_fill(bm, edges=[e for e in bm.edges if e.is_boundary], sides=0)
    bm.to_mesh(am); bm.free()
    # 2) 手メッシュ（Skin→Subsurf→適用）
    d = (TIP - W).normalized(); z = Vector((0, 1, 0)); z = (z - z.dot(d) * d).normalized(); x = d.cross(z).normalized()
    if s == "R": x = -x
    M = Matrix((x, d, z)).transposed()
    T = Matrix.Translation(W) @ M.to_4x4() @ Matrix.Scale(K, 4)
    nm = f"Hand.{s}"
    if nm in O: bpy.data.objects.remove(O[nm], do_unlink=True)
    me = bpy.data.meshes.new(nm); ob = bpy.data.objects.new(nm, me); col.objects.link(ob)
    bm = bmesh.new(); radii = []
    def V(p, rx, ry):
        v = bm.verts.new(p); radii.append((rx, ry)); return v
    w0 = V(Vector((0, -0.026, 0)), 0.022, 0.015)        # 袖の奥まで延長
    p1 = V(Vector((0, 0.022, 0.0)), 0.027, 0.014); bm.edges.new((w0, p1))
    chains = {}
    for fn, (kx, ky, spl, segs, r) in FING.items():
        pts = finger_pts(kx, ky, spl, segs); prev = p1
        for i, p in enumerate(pts):
            rr = r * (1.0 - 0.1 * i)
            v = V(p, rr * (1.4 if i == 0 else 1.0), rr * (1.2 if i == 0 else 1.0)); bm.edges.new((prev, v)); prev = v
        chains[fn] = pts
    prev = w0
    for i, p in enumerate(THUMB):
        rr = 0.0095 * (1.0 - 0.08 * i); v = V(p, rr, rr); bm.edges.new((prev, v)); prev = v
    chains["thumb"] = THUMB
    bm.to_mesh(me); bm.free()
    sk_mod = ob.modifiers.new("Skin", 'SKIN'); sk_mod.use_smooth_shade = True
    sk = me.skin_vertices[0].data
    for i, (rx, ry) in enumerate(radii): sk[i].radius = (rx, ry)
    sk[0].use_root = True
    sub = ob.modifiers.new("Subd", 'SUBSURF'); sub.levels = sub.render_levels = 2
    ob.matrix_world = T
    bpy.ops.object.select_all(action='DESELECT'); ob.select_set(True); bpy.context.view_layer.objects.active = ob
    bpy.ops.object.convert(target='MESH'); bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
    # 3) マテリアル（肌 / 手袋 / 手首バンド）
    me.materials.clear(); me.materials.append(skin); me.materials.append(glove); me.materials.append(band)
    for p in me.polygons:
        t = (p.center - W).dot(d) / K
        if prm("glove", True):
            p.material_index = 2 if -0.004 < t < 0.004 else (1 if t < 0.058 else 0)
        else:
            p.material_index = 0
        p.use_smooth = True
    info[s] = dict(chains={k: [T @ p for p in v] for k, v in chains.items()}, M=M, W=W)
# 4) 指ボーン
bpy.ops.object.select_all(action='DESELECT'); bpy.context.view_layer.objects.active = rig; rig.select_set(True)
bpy.ops.object.mode_set(mode='EDIT'); E = arm.edit_bones
for s in ("L", "R"):
    I = info[s]; W = I["W"]; ch = I["chains"]
    E[f"forearm.{s}"].tail = W; h = E[f"hand.{s}"]; h.head = W; h.tail = ch["middle"][0]
    for fn, pts in ch.items():
        prev = f"hand.{s}"
        for i in range(len(pts) - 1):
            bn = f"{fn}_{i+1:02d}.{s}"
            if bn in E: E.remove(E[bn])
            b = E.new(bn); b.head = pts[i]; b.tail = pts[i + 1]; b.parent = E[prev]; b.use_connect = i > 0; prev = bn
            b.align_roll(I["M"].col[2].to_3d())
bpy.ops.object.mode_set(mode='OBJECT')
for pb in rig.pose.bones: pb.rotation_mode = 'QUATERNION'
# 5) ウェイト
for s in ("L", "R"):
    ob = O[f"Hand.{s}"]
    allowed = {f"hand.{s}"} | {b.name for b in arm.bones if b.name.endswith(f".{s}") and b.name.split("_")[0] in FING.keys() | {"thumb"}}
    for b in arm.bones: b.use_deform = b.name in allowed
    bpy.ops.object.select_all(action='DESELECT'); ob.select_set(True); rig.select_set(True); bpy.context.view_layer.objects.active = rig
    bpy.ops.object.parent_set(type='ARMATURE_AUTO')
for b in arm.bones: b.use_deform = b.name != "root"
restore_pose(state)
RESULT = f"hands ok, bones={len(arm.bones)}"
