# 各パーツを UV 展開し、元のテクスチャ付きメッシュから BaseColor/Roughness をベイク（Cycles GPU）
# 当たらなかった画素は fill 色で埋める。2回目以降の実行は既存 UV/画像に再ベイクする。
# PARAMS:
#   parts : ベイクするパーツ名のリスト（既定: Char_Parts の全メッシュ）
#   res   : {"Hair":4096,"Body":4096,"Coat":4096} 既定 2048
#   fill  : {"Hair":[r,g,b], ...}  既定 [0.5,0.5,0.5]  ※隠れて元に存在しない面の色（服の裏地・髪の内側など）
#   cage  : {"Body":[0.008,0.016]} 既定 [0.015,0.03]（H=2 基準。身長で自動スケール）
#   out_dir : PNG 出力先
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
import os, time
name = SC.get("char_name", "Char"); src = O[name]; k = char_height() / 2.0
col = bpy.data.collections[prm("collection", "Char_Parts")]
parts = prm("parts") or [o.name for o in col.objects if o.type == 'MESH' and not o.name.startswith(("Proxy_", "Hand."))]
RES = prm("res", {}); FILL = prm("fill", {}); CAGE = prm("cage", {"Body": [0.008, 0.016]})
OUT = prm("out_dir"); os.makedirs(OUT, exist_ok=True)
state = set_rest_pose()
arm_mods = []
for n in parts:
    for m in O[n].modifiers:
        if m.type == 'ARMATURE': arm_mods.append((m, m.show_viewport, m.show_render)); m.show_viewport = m.show_render = False
prev = SC.render.engine
SC.render.engine = 'CYCLES'; SC.cycles.device = 'GPU'; SC.cycles.samples = 1
src.hide_set(False); src.hide_render = False
b = SC.render.bake
b.use_selected_to_active = True; b.margin = 16
try: b.margin_type = 'EXTEND'
except Exception: pass
b.use_pass_direct = False; b.use_pass_indirect = False; b.use_pass_color = True
log = []
for pn in parts:
    ob = O[pn]; ob.hide_set(False); t0 = time.time(); r = RES.get(pn, 2048)
    bpy.ops.object.select_all(action='DESELECT'); ob.select_set(True); bpy.context.view_layer.objects.active = ob
    mat = ob.active_material
    if not (mat and mat.node_tree.nodes.get("T_color")):
        while ob.data.uv_layers: ob.data.uv_layers.remove(ob.data.uv_layers[0])
        ob.data.uv_layers.new(name="UVMap")
        bpy.ops.object.mode_set(mode='EDIT'); bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.uv.smart_project(angle_limit=1.15, island_margin=0.002)
        bpy.ops.object.mode_set(mode='OBJECT')
        mat = bpy.data.materials.new(f"M_{pn}"); mat.use_nodes = True
        ob.data.materials.clear(); ob.data.materials.append(mat)
        N = mat.node_tree.nodes; L = mat.node_tree.links
        bsdf = next(n for n in N if n.type == 'BSDF_PRINCIPLED')
        for kind in ("color", "rough"):
            img = bpy.data.images.new(f"{pn}_{kind}", r, r, alpha=True)
            if kind == "rough": img.colorspace_settings.name = 'Non-Color'
            tn = N.new('ShaderNodeTexImage'); tn.image = img; tn.name = f"T_{kind}"
        L.new(N["T_color"].outputs['Color'], bsdf.inputs['Base Color'])
        L.new(N["T_rough"].outputs['Color'], bsdf.inputs['Roughness'])
        bsdf.inputs['Specular IOR Level'].default_value = 0.35
    N = mat.node_tree.nodes
    ce, mr = CAGE.get(pn, [0.015, 0.03]); b.cage_extrusion = ce * k; b.max_ray_distance = mr * k
    for kind, btype in (("color", 'DIFFUSE'), ("rough", 'ROUGHNESS')):
        tn = N[f"T_{kind}"]; img = tn.image; rr = img.size[0]
        img.pixels.foreach_set(np.zeros(rr * rr * 4, np.float32))
        for n in N: n.select = False
        tn.select = True; N.active = tn
        bpy.ops.object.select_all(action='DESELECT'); src.select_set(True); ob.select_set(True); bpy.context.view_layer.objects.active = ob
        bpy.ops.object.bake(type=btype)
        px = np.empty(rr * rr * 4, np.float32); img.pixels.foreach_get(px); px = px.reshape(-1, 4)
        miss = px[:, 3] < 0.5
        px[miss, :3] = FILL.get(pn, [0.5, 0.5, 0.5]) if kind == "color" else 0.7
        px[:, 3] = 1.0; img.pixels.foreach_set(px.ravel())
        img.filepath_raw = os.path.join(OUT, f"{pn}_{kind}.png"); img.file_format = 'PNG'; img.save()
    log.append((pn, round(time.time() - t0, 1)))
src.hide_set(True); src.hide_render = True
for m, v, rr_ in arm_mods: m.show_viewport, m.show_render = v, rr_
restore_pose(state)
SC.render.engine = prev
RESULT = str(log)
