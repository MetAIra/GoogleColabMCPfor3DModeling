# 形状候補（shape_s*.glb）を横並びで読み込み、Workbench で正面/側面/背面をレンダーして比較する
# PARAMS: shape_dir, seeds[list], out_prefix（例: scratchpad\cmp）
# RESULT: 各候補の面数と寸法、出力画像パス
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
import os
for o in list(O):
    if o.name == "Cube": bpy.data.objects.remove(o, do_unlink=True)
col = ensure_collection("Compare")
seeds = prm("seeds", [42, 1234, 2025]); info = []
for i, seed in enumerate(seeds):
    before = set(O)
    bpy.ops.import_scene.gltf(filepath=os.path.join(prm("shape_dir"), f"shape_s{seed}.glb"))
    for o in [o for o in O if o not in before]:
        if o.type != 'MESH':
            bpy.data.objects.remove(o, do_unlink=True); continue
        link_only(o, col); o.name = f"shape_s{seed}"
        o.location.x = (i - (len(seeds) - 1) / 2) * 1.6
        info.append((o.name, len(o.data.polygons), tuple(round(v, 2) for v in o.dimensions)))
H = max(o.dimensions.z for o in col.objects)
SC["char_height"] = H; SC["char_center_y"] = 0.0
paths = render_views(prm("out_prefix"), [("front", 0, 0, 6, 35), ("side", 90, 0, 6, 35), ("back", 180, 0, 6, 35)],
                     visible={o.name for o in col.objects}, engine='BLENDER_WORKBENCH', res=(1500, 1000),
                     color_type='SINGLE', target=(0, 0, 0))
RESULT = f"{info} | {paths}"
