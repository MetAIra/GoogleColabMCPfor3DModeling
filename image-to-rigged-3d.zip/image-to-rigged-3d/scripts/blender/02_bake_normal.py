# 高ポリ → 低ポリ(テクスチャ付き) の法線マップを 4K でベイクし、外れ値を除去して接続する（Cycles GPU）
# PARAMS: name, out_png, size(4096)
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
import time
name = prm("name", SC.get("char_name", "Char")); H = char_height(); k = H / 2.0
lp, hp = O[name], O[f"{name}_highpoly"]
prefs = bpy.context.preferences.addons['cycles'].preferences
for t in ('OPTIX', 'CUDA', 'HIP', 'METAL', 'ONEAPI'):
    try:
        prefs.compute_device_type = t; prefs.get_devices()
        if any(d.type == t for d in prefs.devices):
            for d in prefs.devices: d.use = d.type == t
            break
    except Exception: pass
prev = SC.render.engine
SC.render.engine = 'CYCLES'; SC.cycles.device = 'GPU'; SC.cycles.samples = 1
hp.hide_set(False); hp.hide_render = False
mat = lp.active_material; N = mat.node_tree.nodes; L = mat.node_tree.links
size = prm("size", 4096)
img = bpy.data.images.new(f"{name}_normal", size, size, alpha=False); img.colorspace_settings.name = 'Non-Color'
tn = N.new('ShaderNodeTexImage'); tn.image = img; tn.name = "T_normal"
for n in N: n.select = False
tn.select = True; N.active = tn
bpy.ops.object.select_all(action='DESELECT'); hp.select_set(True); lp.select_set(True); bpy.context.view_layer.objects.active = lp
b = SC.render.bake
b.use_selected_to_active = True; b.cage_extrusion = 0.003 * k; b.max_ray_distance = 0.008 * k
b.normal_space = 'TANGENT'; b.margin = 16
t = time.time(); bpy.ops.object.bake(type='NORMAL'); dt = time.time() - t
# 外れ値（強く傾いた画素）をフラットに置換
px = np.empty(size * size * 4, np.float32); img.pixels.foreach_get(px); px = px.reshape(size, size, 4)
z = px[..., 2] * 2 - 1
bad = z < 0.55
grow = bad.copy()
for dy in (-2, -1, 0, 1, 2):
    for dx in (-2, -1, 0, 1, 2):
        grow |= np.roll(np.roll(bad, dy, 0), dx, 1)
px[grow, 0] = 0.5; px[grow, 1] = 0.5; px[grow, 2] = 1.0
img.pixels.foreach_set(px.ravel())
img.filepath_raw = prm("out_png"); img.file_format = 'PNG'; img.save()
bsdf = next(n for n in N if n.type == 'BSDF_PRINCIPLED')
nm = N.new('ShaderNodeNormalMap'); L.new(tn.outputs['Color'], nm.inputs['Color']); L.new(nm.outputs['Normal'], bsdf.inputs['Normal'])
hp.hide_set(True); hp.hide_render = True
SC.render.engine = prev
RESULT = f"normal bake {dt:.1f}s, outlier px {float(grow.mean()):.4f}"
