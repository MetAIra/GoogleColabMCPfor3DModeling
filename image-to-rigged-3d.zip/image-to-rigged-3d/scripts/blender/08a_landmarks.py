# 08a: パーツ形状から人型ランドマーク（股・膝・足首・背骨・肩・肘・手首・手先）を自動推定して scene に保存
# 前提: 人型・A ポーズ・正面 -Y・足元 z=0。パーツ名 Body / Arm.L / Arm.R（必須）, Hair / Skirt / Coat / Boot.L / Boot.R（任意）
# PARAMS:
#   arm_objects : {"L": "Arm.L", "R": "Arm.R"}（検証用に別オブジェクトを指定可）
#   crotch_ratio: 太ももが接していて股の隙間が検出できない時の股の高さ（身長比, 既定 0.44）
# RESULT: ランドマーク JSON（08b がこれを使う。おかしければ 08b の PARAMS overrides で上書き）
#   crotch_method が "ratio" の場合は推定値なので、正面レンダーで股・膝の位置を目視確認すること
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
import bmesh, heapq, json
H = char_height(); B = verts_world("Body")
Y = float(np.median(B[:, 1])); SC["char_center_y"] = Y
body_top = float(B[:, 2].max())
LM = {}
# ---- 股（脚が左右に分かれる最上部）。太ももが接するキャラでは隙間が膝付近まで現れないので比率にフォールバック ----
crotch = None
for z in np.arange(0.62 * body_top, 0.25 * body_top, -0.005 * H):
    s = B[np.abs(B[:, 2] - z) < 0.004 * H]
    if len(s) < 20: continue
    near_mid = s[(np.abs(s[:, 0]) < 0.006 * H) & (np.abs(s[:, 1] - Y) < 0.06 * H)]
    if len(near_mid) == 0 and (s[:, 0] > 0.01 * H).any() and (s[:, 0] < -0.01 * H).any():
        crotch = float(z); break
method = "gap"
if crotch is None or crotch < 0.38 * H:
    LM["leg_gap_z"] = round(crotch, 3) if crotch else None
    crotch = prm("crotch_ratio", 0.44) * H; method = "ratio"
LM["crotch_method"] = method
hip_z = crotch + 0.015 * H
ankle_z = 0.055 * H
knee_z = ankle_z + 0.46 * (hip_z - ankle_z)
LM.update(crotch=round(crotch, 3), hip_z=round(hip_z, 3), knee_z=round(knee_z, 3), ankle_z=round(ankle_z, 3), body_top=round(body_top, 3))
def leg_point(side, z):
    g = 1 if side == "L" else -1
    Lg = B[(B[:, 0] * g > 0.0025 * H) & (B[:, 2] < crotch + 0.01 * H)]
    for tol in (0.005, 0.01, 0.02, 0.04):
        s = Lg[np.abs(Lg[:, 2] - z) < tol * H]
        if len(s) >= 8: return Vector((float(s[:, 0].mean()), float(s[:, 1].mean()), z))
    s = Lg[np.argsort(np.abs(Lg[:, 2] - z))[:30]]
    return Vector((float(s[:, 0].mean()), float(s[:, 1].mean()), z))
# 背骨（hip〜首上端の比率）
neck_top = body_top + 0.01 * H
span = neck_top - hip_z
sp = {k: hip_z + r * span for k, r in dict(hips=0.03, spine=0.233, chest=0.5, upper=0.733, neck=0.867).items()}
# ---- 腕: 先端（最下点）から表面距離で手の領域を探し、断面が急に太くなる所を手首とする ----
AOBJ = prm("arm_objects", {"L": "Arm.L", "R": "Arm.R"})
def arm_landmarks(side):
    ob = O[AOBJ[side]]; me = ob.data; W = ob.matrix_world
    A = verts_world(ob.name)
    bm = bmesh.new(); bm.from_mesh(me); bm.verts.ensure_lookup_table()
    tip_i = int(np.argmin(A[:, 2]))
    dist = {tip_i: 0.0}; pq = [(0.0, tip_i)]
    lim = 0.08 * H
    while pq:
        d, i = heapq.heappop(pq)
        if d > dist.get(i, 1e9) or d > lim: continue
        v = bm.verts[i]
        for e in v.link_edges:
            u = e.other_vert(v); nd = d + e.calc_length()
            if nd < dist.get(u.index, 1e9): dist[u.index] = nd; heapq.heappush(pq, (nd, u.index))
    bm.free()
    attr = me.attributes.get("tipdist") or me.attributes.new("tipdist", 'FLOAT', 'POINT')
    attr.data.foreach_set("value", [dist.get(i, 9.0) for i in range(len(me.vertices))])
    step = 0.01 * H; bands = []
    for lo in np.arange(0, lim, step):
        idx = [i for i, d in dist.items() if lo <= d < lo + step]
        if not idx: break
        P_ = A[idx]; c = P_.mean(0); r = float(np.max(np.linalg.norm(P_ - c, axis=1)))
        bands.append((float(lo), c, r))
    wrist_d, wrist_c = bands[-1][0], bands[-1][1]
    for j in range(2, len(bands)):
        if bands[j][2] > 1.35 * bands[j - 1][2] and bands[j][0] > 0.02 * H:
            wrist_d, wrist_c = bands[j - 1][0] + 0.5 * step, bands[j - 1][1]; break
    tip = Vector(A[tip_i].tolist()); wrist = Vector(wrist_c.tolist())
    g = 1 if side == "L" else -1
    top = A[A[:, 2] > A[:, 2].max() - 0.06 * H]          # 肩の頂（袖山）付近
    sx = float(np.median(top[:, 0])) - 0.02 * H * g        # 少し内側へ
    sh = Vector((sx, Y, float(A[:, 2].max()) - 0.05 * H))
    elbow = (sh + wrist) / 2 + Vector((0, 0.01 * H, 0))
    return dict(tip=tip, wrist=wrist, wrist_d=wrist_d, shoulder=sh, elbow=elbow)
ARM = {s: arm_landmarks(s) for s in ("L", "R")}
# 肩は左右対称に揃える（腕パーツに襟などの破片が混ざると内側・上側にずれるため、外側の x と低い方の z を採用）
sx = max(abs(ARM["L"]["shoulder"].x), abs(ARM["R"]["shoulder"].x)); sz = min(ARM["L"]["shoulder"].z, ARM["R"]["shoulder"].z)
for s, g in (("L", 1), ("R", -1)):
    ARM[s]["shoulder"] = Vector((sx * g, Y, sz))
    ARM[s]["elbow"] = (ARM[s]["shoulder"] + ARM[s]["wrist"]) / 2 + Vector((0, 0.01 * H, 0))
for s in ARM:
    LM[f"arm.{s}"] = {k: ([round(x, 3) for x in v] if isinstance(v, Vector) else round(v, 3)) for k, v in ARM[s].items()}
# 足先
def toe_y(side):
    nm = f"Boot.{side}"
    V = verts_world(nm) if nm in O else B[(B[:, 2] < 0.08 * H) & ((B[:, 0] > 0) == (side == "L"))]
    return float(V[:, 1].min())
FULL = dict(Y=Y, body_top=body_top, crotch=crotch, hip_z=hip_z, knee_z=knee_z, ankle_z=ankle_z, neck_top=neck_top, sp=sp,
            arm={s: {k: (list(v) if isinstance(v, Vector) else v) for k, v in ARM[s].items()} for s in ARM},
            leg={s: dict(hip=list(leg_point(s, hip_z)), knee=list(leg_point(s, knee_z)),
                         ankle=list(leg_point(s, max(ankle_z, float(B[:, 2].min()) + 0.005 * H))), toe_y=toe_y(s)) for s in ("L", "R")})
SC["landmarks_full"] = json.dumps(FULL)
RESULT = json.dumps(LM)
