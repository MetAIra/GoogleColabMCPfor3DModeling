# 揺れもの物理: 各チェーンに沿った布リボン（Cloth）を作り、チェーンのボーンを Damped Track で追従させる
# 依存ループ回避のため、リボンは本リグの head/spine/hips をコピーする補助リグ "PhysRig" で動かす
# PARAMS:
#   armature : 既定 "Char_Armature"
#   hair : {"bending": 10.0, "mass": 0.15, "width": 0.05}
#   cloth: {"bending": 2.0, "mass": 0.25, "width": 0.06}
#   colliders : ["Body","Arm.L","Arm.R"]
# RESULT: チェーン数
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
H = char_height(); k = H / 2.0; Y = body_center_y()
rig = O[prm("armature", "Char_Armature")]; arm = rig.data
col = bpy.data.collections.get(prm("collection", "Char_Parts")) or SC.collection
state = set_rest_pose()
for n in ("PhysRig", "Proxy_Hair", "Proxy_Cloth"):
    if n in O: bpy.data.objects.remove(O[n], do_unlink=True)
chains = {}
for b in arm.bones:
    if b.name.startswith(("hair_", "skirt.", "coat_")):
        chains.setdefault(b.name.rsplit(".", 1)[0], []).append(b)
for kk in chains: chains[kk].sort(key=lambda b: b.name)
parents = sorted({bs[0].parent.name for bs in chains.values()})
parm = bpy.data.armatures.new("PhysRig"); prig = bpy.data.objects.new("PhysRig", parm); col.objects.link(prig)
bpy.ops.object.select_all(action='DESELECT'); bpy.context.view_layer.objects.active = prig; prig.select_set(True)
bpy.ops.object.mode_set(mode='EDIT')
for n in parents:
    eb = parm.edit_bones.new(n); src = arm.bones[n]; eb.head = src.head_local; eb.tail = src.tail_local
bpy.ops.object.mode_set(mode='OBJECT')
for n in parents:
    c = prig.pose.bones[n].constraints.new('COPY_TRANSFORMS'); c.target = rig; c.subtarget = n
prig.hide_render = True; prig.hide_set(True)
import bmesh
def build(objname, keys, cfg):
    me = bpy.data.meshes.new(objname); ob = bpy.data.objects.new(objname, me); col.objects.link(ob)
    bm = bmesh.new(); groups = {}
    w = cfg["width"] * k
    for key in keys:
        bones = chains[key]
        pts = [bones[0].head_local.copy()] + [b.tail_local.copy() for b in bones]
        rows = []
        for i, p in enumerate(pts):
            d = (pts[min(i + 1, len(pts) - 1)] - pts[max(i - 1, 0)]).normalized()
            radial = Vector((p.x, p.y - Y, 0)); radial = radial.normalized() if radial.length > 1e-4 else Vector((1, 0, 0))
            side = d.cross(radial)
            side = side.normalized() if side.length > 1e-4 else Vector((1, 0, 0))
            rows.append((bm.verts.new(p + side * w / 2), bm.verts.new(p - side * w / 2)))
        for i in range(len(rows) - 1):
            bm.faces.new((rows[i][0], rows[i][1], rows[i + 1][1], rows[i + 1][0]))
        bm.verts.index_update()
        groups.setdefault("pin", []).extend([rows[0][0].index, rows[0][1].index])
        groups.setdefault(bones[0].parent.name, []).extend([v.index for r in rows for v in r])
        for i in range(1, len(rows)):
            groups[f"{key}.pt{i:02d}"] = [rows[i][0].index, rows[i][1].index]
    bm.to_mesh(me); bm.free()
    for g, idx in groups.items():
        vg = ob.vertex_groups.new(name=g); vg.add(idx, 1.0, 'REPLACE')
    m = ob.modifiers.new("Armature", 'ARMATURE'); m.object = prig
    cl = ob.modifiers.new("Cloth", 'CLOTH'); s = cl.settings
    s.vertex_group_mass = "pin"; s.quality = 10; s.mass = cfg["mass"]; s.air_damping = 3.0
    s.tension_stiffness = s.compression_stiffness = 40; s.shear_stiffness = 20; s.bending_stiffness = cfg["bending"]
    s.tension_damping = s.compression_damping = s.shear_damping = 10; s.bending_damping = 2.0
    cl.collision_settings.use_collision = True; cl.collision_settings.distance_min = 0.01 * k
    ob.hide_render = True; ob.display_type = 'WIRE'
    return ob
hk = [x for x in chains if x.startswith("hair_")]; ck = [x for x in chains if not x.startswith("hair_")]
ph = build("Proxy_Hair", hk, prm("hair", {"bending": 10.0, "mass": 0.15, "width": 0.05})) if hk else None
pc = build("Proxy_Cloth", ck, prm("cloth", {"bending": 2.0, "mass": 0.25, "width": 0.06})) if ck else None
for key, bones in chains.items():
    tgt = ph if key.startswith("hair_") else pc
    for i, b in enumerate(bones):
        pb = rig.pose.bones[b.name]
        for c in [c for c in pb.constraints if c.type == 'DAMPED_TRACK']: pb.constraints.remove(c)
        c = pb.constraints.new('DAMPED_TRACK'); c.target = tgt; c.subtarget = f"{key}.pt{i+1:02d}"
for n in prm("colliders", ["Body", "Arm.L", "Arm.R"]):
    if n in O:
        ob = O[n]
        if not any(m.type == 'COLLISION' for m in ob.modifiers): ob.modifiers.new("Collision", 'COLLISION')
        ob.collision.thickness_outer = 0.015 * k
restore_pose(state)
RESULT = f"hair chains {len(hk)}, cloth chains {len(ck)}"
