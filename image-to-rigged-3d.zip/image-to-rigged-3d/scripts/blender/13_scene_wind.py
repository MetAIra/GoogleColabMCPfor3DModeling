# 13: 地面・突風(Wind)＋乱流(Turbulence)・追従カメラ・追従ライトを作り、布キャッシュをベイクする
# 前提: 12 実行済み（scene["anim_end_y"]）。03 のライト Key/Fill/Rim があれば追従させる
# PARAMS:
#   armature : 既定 "Char_Armature"
#   wind_dir : [x,y,z] 風の向き（既定 [0.35,1.0,0.08] = 正面やや右から後方へ）
#   wind_keys: [[frame,strength],...]（既定: 300f まで 0 → 突風）
#   turb_strength : 12
#   bake : True でキャッシュをベイク
# RESULT: ベイク時間
exec(open(SKILL + r"\scripts\blender\_common.py", encoding="utf-8").read(), globals())
import time
H = char_height(); k = H / 2.0; Y = body_center_y()
rig = O[prm("armature", "Char_Armature")]
end_y = float(SC.get("anim_end_y", -17.0 * k))
for n in ("Floor", "Ground", "Wind", "Turb", "CamRig", "CamLook", "FollowCam"):
    if n in O: bpy.data.objects.remove(O[n], do_unlink=True)
# 地面（タイル柄で移動が分かるように）
me = bpy.data.meshes.new("Ground")
me.from_pydata([(-6 * k, 6 * k, 0), (6 * k, 6 * k, 0), (6 * k, end_y - 12 * k, 0), (-6 * k, end_y - 12 * k, 0)], [], [(0, 1, 2, 3)])
g = bpy.data.objects.new("Ground", me); SC.collection.objects.link(g)
mat = bpy.data.materials.get("M_Ground") or bpy.data.materials.new("M_Ground"); mat.use_nodes = True
N = mat.node_tree.nodes; L = mat.node_tree.links
for n in [n for n in N if n.type not in ('BSDF_PRINCIPLED', 'OUTPUT_MATERIAL')]: N.remove(n)
bsdf = next(n for n in N if n.type == 'BSDF_PRINCIPLED')
tc = N.new('ShaderNodeTexCoord'); br = N.new('ShaderNodeTexBrick'); br.inputs['Scale'].default_value = 1.0 / k
br.inputs['Color1'].default_value = (0.055, 0.06, 0.08, 1); br.inputs['Color2'].default_value = (0.045, 0.05, 0.068, 1)
br.inputs['Mortar'].default_value = (0.12, 0.35, 0.55, 1); br.inputs['Mortar Size'].default_value = 0.008
L.new(tc.outputs['Object'], br.inputs['Vector']); L.new(br.outputs['Color'], bsdf.inputs['Base Color'])
bsdf.inputs['Roughness'].default_value = 0.65
g.data.materials.append(mat); g.modifiers.new("Collision", 'COLLISION')
# 風
bpy.ops.object.effector_add(type='WIND', location=(-1.5 * k, end_y - 3 * k, 0.6 * H))
wind = bpy.context.active_object; wind.name = "Wind"
link_only(wind, SC.collection)
wind.rotation_euler = Vector(prm("wind_dir", [0.35, 1.0, 0.08])).normalized().to_track_quat('Z', 'Y').to_euler()
wind.field.shape = 'PLANE'; wind.field.flow = 0.0; wind.field.noise = 1.5; wind.field.seed = 7
keys = prm("wind_keys", [[1, 0], [300, 0], [318, 45], [335, 30], [350, 70], [362, 40], [378, 85], [392, 50], [405, 75], [420, 55]])
for f, s in keys:
    wind.field.strength = s; wind.field.keyframe_insert("strength", frame=f)
bpy.ops.object.effector_add(type='TURBULENCE', location=(0, end_y, 0.6 * H))
turb = bpy.context.active_object; turb.name = "Turb"; link_only(turb, SC.collection)
turb.field.size = 0.2 * H; turb.field.flow = 0.0
turb.field.strength = 0.0; turb.field.keyframe_insert("strength", frame=300)
turb.field.strength = prm("turb_strength", 12.0); turb.field.keyframe_insert("strength", frame=325)
# 追従カメラ＋ライト
camrig = bpy.data.objects.new("CamRig", None); SC.collection.objects.link(camrig)
c = camrig.constraints.new('COPY_LOCATION'); c.target = rig; c.use_z = False
look = bpy.data.objects.new("CamLook", None); SC.collection.objects.link(look); look.parent = camrig; look.location = (0, Y, 0.5 * H)
cd = bpy.data.cameras.new("FollowCam"); cd.lens = 40
cam = bpy.data.objects.new("FollowCam", cd); SC.collection.objects.link(cam)
cam.parent = camrig; cam.location = (1.8 * H, Y - 1.17 * H, 0.72 * H)
tt = cam.constraints.new('TRACK_TO'); tt.target = look; tt.track_axis = 'TRACK_NEGATIVE_Z'; tt.up_axis = 'UP_Y'
SC.camera = cam
SC.frame_set(SC.frame_start); bpy.context.view_layer.update()
for n in ("Key", "Fill", "Rim"):
    if n in O:
        l = O[n]; mw = l.matrix_world.copy(); l.parent = camrig
        l.matrix_parent_inverse = camrig.matrix_world.inverted(); l.matrix_world = mw
if SC.world:
    bg = next((n for n in SC.world.node_tree.nodes if n.type == 'BACKGROUND'), None)
    if bg: bg.inputs['Color'].default_value = (0.035, 0.045, 0.07, 1); bg.inputs['Strength'].default_value = 1.5
for n in ("Proxy_Hair", "Proxy_Cloth"):
    if n in O:
        cl = next(m for m in O[n].modifiers if m.type == 'CLOTH')
        cl.point_cache.frame_start, cl.point_cache.frame_end = SC.frame_start, SC.frame_end
dt = 0.0
if prm("bake", True):
    SC.frame_set(SC.frame_start); t = time.time()
    with bpy.context.temp_override(scene=SC):
        bpy.ops.ptcache.free_bake_all(); bpy.ops.ptcache.bake_all(bake=True)
    dt = time.time() - t
RESULT = f"scene ok, cloth bake {dt:.1f}s"
