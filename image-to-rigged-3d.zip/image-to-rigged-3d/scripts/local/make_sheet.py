# レンダー画像を1枚のコンタクトシートにまとめる（Read で一度に確認するため）
# 使い方: python make_sheet.py <out.png> <cols> <cell_w> <cell_h> <img1> <img2> ...   （ラベルはファイル名末尾）
import sys
from PIL import Image, ImageDraw
out, cols, cw, ch = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4])
paths = sys.argv[5:]
rows = (len(paths) + cols - 1) // cols
sheet = Image.new('RGB', (cw * cols, ch * rows), (40, 40, 40))
for i, p in enumerate(paths):
    im = Image.open(p).convert('RGB'); im.thumbnail((cw, ch))
    x, y = (i % cols) * cw, (i // cols) * ch
    sheet.paste(im, (x, y)); ImageDraw.Draw(sheet).text((x + 6, y + 6), p.replace('\\', '/').split('/')[-1][:40], fill=(255, 255, 0))
sheet.save(out); print(out, sheet.size)
