---
name: image-to-rigged-3d
description: キャラクター画像1枚から、Google Colab MCP（A100 で Hunyuan3D-2.1 / Hunyuan3D-Part を実行）と Blender MCP を使い、有料 API なしで「4K PBR テクスチャ付き・パーツ分割・ボーン/ウェイト・5本指の手・髪/服の揺れもの物理・歩く/走る/ジャンプ/風のアニメーション」まで作る。ユーザーが「○○の画像からリアルな3Dモデルを作って」「画像から3Dモデル（リグ付き）を作って」「この画像を3D化して動かして」などと頼んだときに使う。
---

# 画像 → テクスチャ付き・リグ付き 3D キャラクター

このフォルダ（`G:\マイドライブ\003_Blender\blender-googlecolab`）で 2026-10-02 に AIra を作った手順の再現。
人型キャラ（A ポーズ・正面向きの全身画像）が対象。人型でない物体は Phase 4 で止める。

## 全体像（目安 1〜1.5 時間）

| Phase | 内容 | 実行場所 | 主なスクリプト |
|---|---|---|---|
| 0 | 準備（接続・環境構築） | Colab | `colab/install_hy.sh`, `colab/install_part.sh` |
| 1 | 前処理（背景除去・余計な物の除去） | Colab | `colab/preprocess.py` |
| 2 | 形状 3 候補 → 比較して採用 | Colab → Blender | `colab/gen_shape.py`, `blender/00_compare_shapes.py` |
| 3 | 4K PBR テクスチャ | Colab | `colab/gen_tex.py` |
| 4 | 取り込み・法線ベイク・スタジオレンダー（静止モデル完成） | Blender | `01`, `02`, `03` |
| 5 | パーツ分解（多段）→ 最終パーツ組み立て | Colab → Blender | `colab/run_xpart.py`, `04`, `05` |
| 6 | パーツへテクスチャ再ベイク・隠れ面の塗り替え | Blender | `06`, `07` |
| 7 | 骨格・ウェイト・手の作り直し・ポーズテスト | Blender | `08a`, `08b`, `09`, `10`, `90` |
| 8 | 揺れもの物理・アクション・風・動画 | Blender | `11`, `12`, `13`, `14` |
| 9 | 保存・書き出し・報告 | Blender | — |

スクリプトは `.claude/skills/image-to-rigged-3d/scripts/` 配下（以下 `SKILL` = このスキルのフォルダの絶対パス）。

## 依頼の解釈

- 「○○の画像」→ `characters/*/source/` から該当画像を探す（例 `characters/AIra/source/AIra_noback_front.png`）。新しい画像は `characters/<Name>/source/` に置く。複数候補や見つからない場合だけ確認する。
- キャラ名 `<Name>` は画像のフォルダ名かファイル名から決める。すべて `characters/<Name>/` の下に置く: 作業 `work/`、レンダー `renders/`、成果物 `<Name>.blend`, `<Name>_rigged.blend`, `export/<Name>.glb`。
- 途中で長く無言にならないよう、各 Phase の区切りで短く進捗を伝える。Phase 4 完了時（静止モデル）と最後に、画像を見せて報告する。

## 参照画像セット（`characters/<Name>/source/ref/`）がある場合

3d-reference-images スキルで作った画像があれば、元画像の代わりに使う（無ければ元画像 1 枚で通常どおり）。
入力が 1 枚だけで精度を上げたいとユーザーが望む場合は、先に 3d-reference-images スキルで画像セットを作ってもらう。

| 画像 | 使う場所 |
|---|---|
| `01_front_clean.png` | Phase 1〜3 の主入力（前処理→形状→テクスチャ）。A ポーズ・脚の隙間ありなので 08a の股検出が "gap" で通りやすい |
| `02_back`, `03_left`, `04_right` | Phase 2 の候補比較: `00_compare_shapes` の back/side レンダーと見比べ、シルエットが近いシードを選ぶ。Phase 3 で `gen_tex.py` に `front,back,left,right` の順でカンマ区切り指定（**試験的**: 複数参照での完走は確認済み（2026-10-02、2枚で171秒）だが、実際の背面/側面画像での品質向上は未検証。単一画像版も作って見比べ、良い方を採用）。各画像も preprocess.py を通してから渡す |
| `20/21_body_base` | Phase 6 の 07 で隠れ面の塗り色（zones）を決める根拠。**試験的**に素体だけ gen_shape して Body の代わりに使う手もある（身長・中心を合わせて配置が必要） |
| `30〜32 髪`, `40 服`, `50 小物` | Phase 5 のパーツ割り当て判断、Phase 6 の fill 色（髪の内側・裏地） |
| `60_hands` | 10_hands の glove/skin/band 色と手袋の範囲 |
| `design_notes.md` | パレット（fill/肌色）、発光色（01 の emission）、非対称デザインの確認 |

## 共通の作法（重要）

### パスの対応（Google Drive 経由でファイル共有）
- ローカル `G:\マイドライブ\X` ＝ Colab `/content/drive/MyDrive/X`。Colab で Drive に書いたファイルはローカルに同期される（数秒〜数十秒）。
- 同期待ちは Bash の until ループ（`sleep` 単独は禁止）:
  `until [ -f "<path>" ] && [ "$(stat -c %s "<path>")" = "<size>" ]; do sleep 3; done`
- スキルの Colab スクリプトも Drive 経由で見える: `/content/drive/MyDrive/003_Blender/blender-googlecolab/.claude/skills/image-to-rigged-3d/scripts/colab/`。見えなければ Read した内容を `%%writefile` で書き出す。

### Colab MCP
- 最初に ToolSearch で `select:mcp__colab-mcp__open_colab_browser_connection` を読み込み接続 → 続けて `add_code_cell, run_code_cell, update_cell, get_cells` を読み込む。
- ランタイムが GPU（A100）でなければ、ユーザーに「ランタイムのタイプを A100 に変更」を依頼。Drive マウント時の認証もユーザー操作。
- 長い処理（インストール・生成）は **必ず** `subprocess.Popen('... > /content/xxx.log 2>&1', shell=True)` でバックグラウンド起動し、`!sleep 60; tail -c 800 /content/xxx.log` のセルで確認する（セル実行は 120 秒を超えると MCP 側でバックグラウンド化される）。
- `!` 行に複数行の `python -c "..."` を書かない（構文エラーになる）。スクリプトはファイルにしてから実行。
- `pkill -f <name>` を `!` 行で使うと自分自身のシェルも殺す → Python の `os.kill` で止める。

### Blender MCP
- 最初に `get_addon_status` と `get_scene_info`。アドオンが古い場合 `get_viewport_screenshot` は無く、`print` も返らない。
- **スクリプト実行の型**（戻り値は例外メッセージで受け取る）:
  ```python
  import bpy
  SKILL = r"G:\マイドライブ\003_Blender\blender-googlecolab\.claude\skills\image-to-rigged-3d"
  g = {"SKILL": SKILL, "PARAMS": {...}}
  exec(open(SKILL + r"\scripts\blender\08a_landmarks.py", encoding="utf-8").read(), g)
  raise Exception(g["RESULT"])
  ```
- 120 秒を超える処理（ベイク・動画）はバックグラウンド化され、完了通知を待てばよい。
- 見た目の確認は「レンダーして scratchpad に PNG → Read」。複数画像は `python SKILL/scripts/local/make_sheet.py out.png <cols> <w> <h> img...` で1枚にまとめて Read。
- ボーンの可視化: ボーンごとに POLY スプライン（bevel_depth≈0.005H）のカーブ "RigViz" を作り、メッシュのみ／カーブのみ（透過背景）を別々にレンダーして PIL で合成する（Workbench の X 線では見えない）。
- 座標規約: 正面 = -Y、キャラの左 = +X（`.L`）、上 = +Z、足元 z=0。身長 H は `scene["char_height"]`（多くの寸法は H 比で自動スケール）。

## Phase 0: 準備
1. Colab 接続 → `!nvidia-smi; nvcc --version; python --version` を確認（A100 40GB / nvcc 13 前提。nvcc 12 系なら `install_hy.sh` の `TORCH_INDEX` を cu12x に）。
2. Drive マウント（`drive.mount('/content/drive')`）。`PROJ=/content/drive/MyDrive/003_Blender/blender-googlecolab`。
3. `install_hy.sh` と `install_part.sh` を `/content` にコピーし、**両方バックグラウンドで並行実行**（ログ末尾に `INSTALL_HY_DONE` / `INSTALL_PART_DONE`）。待つ間に Phase 1。

## Phase 1: 前処理
- `/content/hy/bin/python preprocess.py <img> /content/work/<name>_input.png` → `_preview.jpg` を Drive 経由で Read して確認。
- ペット・小物・エフェクト等が残っていたら: ローカルで元画像を格子付きでクロップ表示（PIL）して座標を読み、`[[y0,y1,x0,x1],...]` を第3引数に渡して再実行。髪の透け部分を消し過ぎないこと。
- rembg のモデルは hy 環境で動く（isnet-anime）。初回 176MB ダウンロードあり。

## Phase 2: 形状候補と採用
- `gen_shape.py <input> /content/work/<name>/shape 42,1234,2025 512`（1シード約1分、各約150万面）→ Drive `characters/<Name>/work/shape/` にコピー → 同期待ち。
- Blender で `00_compare_shapes.py`（PARAMS: `shape_dir`, `seeds`, `out_prefix`）→ front/side/back を Read。
- **採用基準**: 顔が崩れていない（口・目の凹凸が変でない）＞ 背面の髪が塊状でなく滑らか ＞ 衣装の再現度。迷えば顔優先。

## Phase 3: テクスチャ（採用が決まったらすぐ開始。約3分）
- `gen_tex.py shape_s<seed>.glb <input> /content/work/<name>/tex/textured_mesh.obj 100000`（4K で出力）。
- 並行して X-Part 入力を作る: `/content/hp/bin/python decimate.py shape_s<seed>.glb /content/work/<name>/hp400k.obj 400000`。
- textured_mesh* を Drive `characters/<Name>/work/tex/` にコピー。

## Phase 4: 静止モデル完成
1. `01_import_textured.py`（PARAMS: `tex_dir`, `highpoly_glb`, `name`, `rough_remap`=[0.4,0.85], `emission`=発光色の HSV 範囲。発光色が無いキャラは None）。
   - 発光の色相はアルベドの HSV 分布から決める（シアン系なら hue 0.47〜0.61）。
2. `02_bake_normal.py`（`out_png`=`characters/<Name>/work/tex/<Name>_normal.png`）。外れ値率が数%以下なら OK。
3. `03_studio.py`（`out_dir`=`characters/<Name>/renders`）→ hero/front/bust を Read して品質確認。白飛びするならブルームの Threshold を上げる。
4. `bpy.ops.wm.save_as_mainfile(characters/<Name>/<Name>.blend)`、`characters/<Name>/export/<Name>.glb` を書き出し、ユーザーに中間報告。

## Phase 5: パーツ分解
1. `run_xpart.py /content/work/<name>/hp400k.obj /content/work/<name>/xp1`（1〜2 分、`PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True`）→ Drive にコピー。
2. `04_import_parts.py`（`part_dir`, `prefix`="P", `out_prefix`）→ 単体レンダーをシートにして識別。
3. **複数の意味領域が混ざったパーツ**（例: 髪＋頭＋両腕＋袖）があれば、その `part_XX.glb` を入力に X-Part を再実行（prefix "Q", "R"…）。通常 2 段で腕が分かれる。最大 3 段。
4. **髪と頭（顔）は分離できない**（AABB 指定でも失敗した）→ 1 つの "Hair" として扱い、ウェイトで顔＝head、髪束＝髪チェーンに分ける。
5. 小さな髪束・アホ毛片は Hair に統合。胸元などの小物は独立パーツ（後で rigid）。
6. `05_assemble_parts.py`（`groups` マッピング）→ RESULT の中心 x で L/R を確認（+X がキャラの左）。
   - 必須名: `Body`（首〜足、服の下が補完された体）, `Arm.L`, `Arm.R`（袖ごと）。任意: `Hair`, `Coat`, `Skirt`, `Boot.L`, `Boot.R`, 小物。
   - スカート前面が Body 側に入ることがある（問題なし）。

## Phase 6: パーツのテクスチャ
1. `06_bake_parts.py`（`res`: Hair/Body/Coat=4096, 他 2048/1024、`fill`: 隠れ面の色＝髪の内側は髪色、服の裏地は暗色、体は下地色、`out_dir`=`characters/<Name>/work/parts_tex`）。margin=16 で継ぎ目の白線を防ぐ。
2. `07_body_occlusion.py`（`zones`: 露出肌の高さ帯を H 比で。例 太もも [[0.31,0.41,[0.92,0.68,0.60]]]）→ 体の背中に服/髪の色が写り込むのを解消。
3. 組み上げ全体と Body 単体（前/後）をレンダーして確認。

## Phase 7: リグ
1. `08a_landmarks.py` → RESULT を検証: `hip_z≈0.45H`, `knee_z≈0.24H`, `ankle_z≈0.055H`, 手首は肩より下・手先は手首より下、左右対称に近い。おかしい値は 08b の `overrides` で上書き。
2. `08b_build_armature.py`（`armature`="Char_Armature" か `<Name>_Armature`）→ RigViz 合成画像で確認（髪チェーンが髪の中を通るか、スカート/コートのチェーンが長さゼロでないか）。
3. `09_weights.py`（`rigid`: {"Chest_Acc":"upper_chest"} など）→ 無ウェイト頂点 0 を確認。
4. `10_hands.py`（`glove`, `skin_color`, `glove_color`, `band_color` を画像に合わせる）→ AI 生成の手は指が融合した「ミトン」なので必ず作り直す。
5. `90_pose_test.py` → 腕/脚/首/指（左グー・右ピース）の変形を確認。破綻があれば該当パーツの許可ボーン集合（09 の `extra_sets`）を調整して 09 を再実行。

## Phase 8: 物理・アクション・動画
1. `11_physics.py`（髪 bending 10 / 服 bending 2）。PhysRig（head/spine/hips のコピー）でリボンを動かし、チェーンは Damped Track で追従（依存ループ回避）。
2. `12_anim_actions.py`（歩き 1.3 / 走り 3.8 / H=2 基準）→ 420f。
3. `13_scene_wind.py`（風向き・突風キー・乱流、追従カメラとライト、布キャッシュのベイク ≈1 分）。
4. `14_render.py` mode=frames で 10 枚確認 → 問題なければ mode=video（`characters/<Name>/renders/<Name>_walk_run_jump_wind_`、約 1.5 分）。
5. 確認ポイント: 走りで髪が後方に流れる / ジャンプで空中に浮く / 風区間で髪とコートが風下へ / 暗くなっていない（ライト追従）。

## Phase 9: 仕上げ
- `characters/<Name>/<Name>_rigged.blend` に保存。必要なら FBX/GLB を書き出し（揺れもの物理は Blender 専用。エンジンではスプリングボーンに置き換えが必要と伝える）。
- 報告に含める: 成果物パス、動画、限界（髪と顔が一体・髪は 5 本チェーン近似・足の滑り（IK 無し）・大きく翻ると裏地が見える）、次の改善案（実写動画モーキャプ GVHMR、足 IK、髪チェーン増加、顔の作り直し）。
- Colab ランタイムの切断をユーザーに促す（コンピューティングユニット消費）。
- ライセンス: Hunyuan3D-2.1 / Hunyuan3D-Part は Tencent Hunyuan Community/Non-Commercial License（EU/英国/韓国は対象外）。商用利用は規約確認が必要と一言添える。

## 既知の落とし穴（今回すべて踏んだもの）
- Colab 既定 Python 3.13 では Hunyuan の requirements が入らない → py3.10 の uv venv。`bpy==4.0` は wheel が無い → 除外し mesh_utils の import を任意化。
- `setuptools>=80` で `pkg_resources` が消え pytorch_lightning が落ちる → `<80`。
- `compile_mesh_painter.sh` は `python3-config` が無く失敗 → 直接 c++ でビルド（install_hy.sh 済み）。
- テクスチャは既定で 2K に縮小保存 → gen_tex.py で `downsample=False`。
- X-Part: flash_attn 必須（wheel 指定）、P3-SAM の bs=64 は 40GB で OOM → 16。
- 法線ベイクは cage を大きくすると薄い髪で誤ヒット → extrusion 0.003·k / max_ray 0.008·k。
- パーツベイクで margin=0 だと UV 継ぎ目に白線 → margin 16。
- 体の背中は「距離」ではなく「外向きレイが他パーツに遮られるか」で隠れ判定する（髪の内面が密着しているため）。
- 手続き的アニメの回転は「ワールド軸→ボーンローカル」変換（wq）で指定する。脚/腕は X 負で前、膝は X 正で曲げ、背骨は X 正で前傾。
- ライトを原点に置いたまま走らせると暗くなる → CamRig に追従させる（13 で実施）。
- Bash の heredoc 内 Python で `r"\\scripts\\blender"` を組み立てると `\b` がバックスペースになることがある → スクリプトは Write ツールで直接書く。
